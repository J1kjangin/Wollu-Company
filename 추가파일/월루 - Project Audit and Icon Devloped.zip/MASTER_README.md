# MASTER README — Workspace Architect 정밀 개조 파이프라인

> **이 문서 하나만 읽으면 전체 작업을 순서대로 수행할 수 있다.**
> 각 페이즈는 **입력 → 산출물 → 통과 기준(Gate)** 을 가진다.
> Gate를 통과하지 못한 페이즈는 다음 페이즈로 넘어가지 않는다. 예외 없음.

---

## 0. 프로젝트 정체 (Identity)

| 항목 | 값 |
|---|---|
| 이름 | Workspace Architect |
| 장르 | 방치형(idle/incremental) 사무실 인테리어 시뮬레이션 |
| 언어 | 한국어 (`<html lang="ko">`) |
| 폼팩터 | 모바일 세로 (`max-width: 480px`, `height: 94vh`) |
| 런타임 | 순수 바닐라 JS · classic `<script>` · 빌드 없음 · `file://` 직접 실행 가능 |
| 아키텍처 | IIFE + `window.Workspace` 전역 네임스페이스 (ES Module 미사용 — 의도적) |
| 저장 | `localStorage['workspaceArchitectSave']`, `SAVE_VERSION: 1` |
| 규모 | 5 JS 모듈(781 LOC) · 1 CSS(300 LOC) · 1 HTML(127 LOC) · 아이템 100종 · 직급 11단 |

**절대 불변 제약 (Hard Constraints)** — 모든 페이즈에서 위반 금지:
1. **빌드 스텝을 도입하지 않는다.** npm / bundler / transpile 없음.
2. **`file://` 더블클릭 실행이 계속 동작해야 한다.** → `type="module"`, `fetch()`, 외부 CDN 필수 의존 금지.
3. **`window.Workspace` 네임스페이스 패턴을 유지한다.** 새 모듈도 IIFE로 붙인다.
4. **기존 세이브를 깨지 않는다.** 스키마 변경 시 `SAVE_VERSION` 상승 + 마이그레이션 함수 필수.
5. **단방향 데이터 흐름 유지.** `ui.js`는 state를 읽기만 한다. state 변경은 `gameState.js`에서만.

---

## 1. 페이즈 파이프라인

### `P0` 파이프라인 구축 ✅
- **산출물**: `MASTER_README.md` (본 문서)
- **Gate**: P1~P6의 산출물 경로·통과 기준이 모두 명시되었는가

### `P1` 외과적 코드 감사
- **입력**: `uploads/workspace_architect_modular/**`
- **산출물**: `docs/ANALYSIS.md`
- **필수 포함**: 모듈 의존 그래프 · 데이터 무결성 결함 · 런타임 결함(심각도 등급) · 죽은 코드 · 밸런스 수치 검증 · 접근성 감사
- **Gate**: 모든 결함이 `파일:라인` 근거와 **재현 조건**을 가진다. 추측 금지.

### `P2` 디자인 교리 수립
- **입력**: `docs/ANALYSIS.md` + 현재 CSS 팔레트 + 게임 서사(인턴→사장, 사직서 반려)
- **산출물**: `docs/DESIGN_DOCTRINE.md`
- **필수 포함**: 테마 키워드 세트(5개 축) · 컬러 토큰 · 타입 스케일 · 아이콘 기하 규격 · 금지 목록
- **Gate**: 기존 팔레트(`#1e1e2f` / `#ffd700` / `#00ffcc`)와 **연속성**을 가지면서 교리로 격상되었는가. 무근거 리브랜딩 금지.

### `P3` 자체 아이콘 패밀리 제작 ★최우선
- **입력**: `docs/DESIGN_DOCTRINE.md` §4 (기하 규격) + `data.js` 아이템 100종
- **산출물**:
  - `icons/wa-icons.js` — 글리프 레지스트리 + `<wa-icon>` 커스텀 엘리먼트
  - `icons/ICON_SPEC.md` — 규격서 / 명명 규칙 / 확장 절차
- **Gate (4중 검수)**:
  - **G3-a 커버리지**: 아이템 100종 전부 글리프 매핑. 미매핑 0건.
  - **G3-b 충돌 0**: 서로 다른 아이템이 동일 글리프를 공유하지 않는다. (현재 이모지: 60/100 충돌)
  - **G3-c 의미 정합**: 이름과 글리프의 의미가 일치한다. (현재: 8건 오배정)
  - **G3-d 기하 일관**: 전 글리프가 동일 viewBox·stroke·그리드·라인캡 규격 준수.

### `P4` 아이콘 스펙시멘 (시각 검수)
- **입력**: `icons/wa-icons.js`
- **산출물**: `Icon Foundry.dc.html`
- **필수 포함**: 전 글리프 그리드 · 패밀리별 분류 · 사이즈 램프(16/24/32/48) · 등급 처리 · 실제 게임 UI 인컨텍스트 대조(Before 이모지 / After 자체 아이콘)
- **Gate**: 육안으로 스트로크 굵기·시각 무게·광학 중심이 튀는 글리프가 없는가

### `P5` 코딩 스타일 디렉티브
- **산출물**: `docs/CODING_DIRECTIVE.md`
- **필수 포함**: 레이어 규칙 · 명명 규칙 · DOM 접근 규칙 · 상태 변경 규칙 · 렌더 규칙 · 리뷰 체크리스트 · 안티패턴 사례(본 코드베이스 실물 인용)
- **Gate**: 모든 규칙에 **"왜"** 와 **본 코드베이스의 실제 위반 사례**가 붙어 있는가. 일반론 금지.

### `P6` 트리플A 업그레이드 로드맵
- **산출물**: `docs/UPGRADE_ROADMAP.md`
- **필수 포함**: 속도 / 기능 / UX 3축 · 결함 ID 역참조 · 난이도·효과 매트릭스 · 우선순위 스프린트 · 구현 스니펫
- **Gate**: 모든 항목이 P1 결함 ID를 참조하거나 측정 가능한 목표 수치를 가진다

### `P7` 통합 빌드
- **입력**: 기준선 + P3 아이콘 + P5 디렉티브 + P6 로드맵 Sprint 1~4
- **산출물**: `build/workspace_architect/` (실행 가능한 전체 빌드) + `docs/P7_INTEGRATION.md`
- **Gate**: 치명 4건 전멸 · 이모지 0건 · `alert`/`confirm` 0건 · `WAIcons.audit().pass` · 콘솔 에러 0 · `file://` 실행 유지

---

## 2. 산출물 트리

```
MASTER_README.md              ← P0 (본 문서 · 단일 진입점)
docs/
  ANALYSIS.md                 ← P1 감사 보고서
  SPRINT7_SPEC.md             ← Sprint 7 시스템 명세 (강화·업적·일일·NPC)
  DESIGN_DOCTRINE.md          ← P2 디자인 교리 + 테마 키워드
  CODING_DIRECTIVE.md         ← P5 코딩 스타일 방안
  UPGRADE_ROADMAP.md          ← P6 트리플A 업그레이드 방안
icons/
  wa-icons.js                 ← P3 아이콘 패밀리 (런타임 자산)
  ICON_SPEC.md                ← P3 규격서
Icon Foundry.dc.html          ← P4 스펙시멘 / 시각 검수 화면
build/workspace_architect/    ← P7 통합 빌드 (실행 대상)
  index.html  css/  js/  icons/
  js/regressionTest.js        ← 회귀 테스트 24종 (콘솔 주입 실행)
docs/
  P7_INTEGRATION.md           ← P7 통합 보고서 / 회귀 테스트 절차
uploads/workspace_architect_modular/
                              ← 원본. 끝까지 수정하지 않는다(읽기 전용 기준선).
```

**원본 불가침 원칙**: `uploads/` 아래 원본은 감사 기준선(baseline)이다.
통합 작업은 별도 승인 후 별도 페이즈(`P7 INTEGRATE`)로 수행한다.

---

## 3. 진행 상태 보드

| 페이즈 | 산출물 | 상태 | Gate |
|---|---|---|---|
| P0 | `MASTER_README.md` | ✅ 완료 | 통과 |
| P1 | `docs/ANALYSIS.md` | ✅ 완료 | 통과 (결함 23건 · 전건 라인 근거) |
| P2 | `docs/DESIGN_DOCTRINE.md` | ✅ 완료 | 통과 (테마 5축 · 팔레트 연속성 확보) |
| P3 | `icons/wa-icons.js` + `ICON_SPEC.md` | ✅ 완료 | 통과 (커버리지 100/100 · 충돌 0 · 오배정 0) |
| P4 | `Icon Foundry.dc.html` | ✅ 완료 | 통과 |
| P5 | `docs/CODING_DIRECTIVE.md` | ✅ 완료 | 통과 |
| P6 | `docs/UPGRADE_ROADMAP.md` | ✅ 완료 | 통과 |
| P7 | 통합 빌드 `build/workspace_architect/` | ✅ 완료 | 통과 (Sprint 1–6 · 회귀 24/24) |
| S7 | `docs/SPRINT7_SPEC.md` 시스템 명세 | ✅ 명세 완료 | 구현은 `F-2` 종속 |
| P8 | F-2 성장 곡선 / F-5 set 시스템 전환 | ⬜ 보류 — 단위 상의 중 | — |

---

## 4. 읽는 순서 (신규 참여자용)

1. 본 문서 §0 (제약 조건) — **이걸 모르고 코드를 만지면 `file://` 실행이 깨진다**
2. `docs/ANALYSIS.md` — 무엇이 왜 문제인가
3. `docs/DESIGN_DOCTRINE.md` — 무엇을 지향하는가
4. `Icon Foundry.dc.html` — 결과물을 눈으로 확인
5. `docs/CODING_DIRECTIVE.md` — 코드를 쓸 때의 규칙
6. `docs/UPGRADE_ROADMAP.md` — 다음에 무엇을 할 것인가
7. `docs/P7_INTEGRATION.md` — 무엇이 실제로 반영되었는가 / 회귀 테스트 절차
8. `build/workspace_architect/index.html` — 실행

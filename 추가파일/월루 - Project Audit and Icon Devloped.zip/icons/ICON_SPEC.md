# P3 · 아이콘 규격서 (ICON SPEC)

패밀리명 **CYANOTYPE** · `icons/wa-icons.js` · v1.0.0
글리프 114종 (아이템 100 + 시스템 14) · 커버리지 100/100 · 충돌 0 · 오배정 0

---

## 1. 기하 규격 (불변)

| 항목 | 값 |
|---|---|
| viewBox | `0 0 24 24` |
| 라이브 영역 | 20×20 (여백 2 유닛) |
| stroke-width | `1.5` — **단일 굵기. 예외 없음** |
| stroke-linecap | `square` |
| stroke-linejoin | `miter` |
| fill | `none` |
| 색 | `currentColor` 상속 (글리프에 색을 하드코딩하지 않는다) |
| 좌표 | 정수 또는 `.5` 오프셋만 |
| 투상 | 정면도(front elevation) 또는 평면도(plan). **원근·아이소메트릭 금지** |
| path 예산 | 글리프당 최대 12. 표준 4~8 |
| 곡선 | 대상이 실제로 둥글 때만 (머그 손잡이 · 식물 · 렌즈 · 곡면 모니터) |

`.5` 오프셋 규칙의 이유: stroke 1.5는 중심선 기준 ±0.75로 렌더된다. 좌표를 `.5`에 두면 24px 기준 렌더에서 획의 양끝이 픽셀 경계에 정렬돼 흐려지지 않는다.

---

## 2. 명명 규칙

```
{패밀리}-{대상}[-{변형}]
```
kebab-case · ASCII 소문자 · 한글 금지 (라벨은 `ITEM` / `SYS_LABEL` 테이블이 담당)

**패밀리 18종**

| 접두 | 의미 | 수 |
|---|---|---|
| `sys` | 시스템 / UI | 14 |
| `desk` | 책상 | 4 |
| `seat` | 의자 | 5 |
| `note` | 노트 · 서식 | 4 |
| `pen` | 필기구 | 3 |
| `pc` | 컴퓨터 | 15 |
| `cup` | 음료 | 6 |
| `app` | 가전 | 5 |
| `food` | 식음 | 2 |
| `store` | 수납 | 8 |
| `eq` | 사무기기 | 12 |
| `deco` | 장식 | 9 |
| `flora` | 식물 | 5 |
| `lamp` | 조명 | 3 |
| `time` | 시계 | 3 |
| `sofa` | 소파 | 3 |
| `table` | 테이블 | 3 |
| `space` | 공간 · 엔드게임 | 10 |

---

## 3. 티어 표현 규칙 ★ 이 패밀리의 핵심

업그레이드는 **장식이 아니라 형태**로 표현한다. 허용된 티어축은 4개뿐이다:

| 축 | 사용 예 |
|---|---|
| **확장 (extension)** | 모니터: 13→19→듀얼→곡면 / 화이트보드: `eq-board` → `eq-board-xl` |
| **반복 (repetition)** | 키보드 키 행 2→3 / 소파 쿠션 1→2→3 / 서류함 1단→3단 |
| **실루엣 (silhouette)** | 마우스: 대칭 → 무선 → 인체공학(엄지윙) → 프로(측면버튼) |
| **구조 추가 (accretion)** | 캐비닛 → 고급 캐비닛(4단+굽) / 책장 → 대형 → 차장실(유리문+갓) |

**금지**: 반짝임, 별, 왕관, 크기 확대, 색 하드코딩으로 티어를 표현하는 것.

---

## 4. API

```js
// 아이템 id로 (권장 — aria-label 자동)
element.innerHTML = WAIcons.forItem('item_18', { size: 28 });

// 글리프 id로
element.innerHTML = WAIcons.svg('sys-rebirth', { size: 20, label: '환생' });

// 선언적 (커스텀 엘리먼트 · Shadow DOM)
<wa-icon item="item_18" size="28"></wa-icon>
<wa-icon name="sys-shop" size="20" label="상점"></wa-icon>

// 조회
WAIcons.glyphOf('item_18');   // 'pc-monitor-dual'
WAIcons.labelOf('sofa-3');    // '3인 소파'
WAIcons.familyOf('sofa-3');   // 'sofa'
WAIcons.families();           // { sofa: ['sofa-1', ...], ... }
WAIcons.RARITY.mythic.color;  // 'oklch(0.84 0.17 88)'

// 게이트 자체 검증
WAIcons.audit();  // { glyphCount, coverage, missing, collisions, orphans, violations, pass }
```

`opts`: `size`(기본 24) · `label`(있으면 `role="img"`+`aria-label`, 없으면 `aria-hidden`) · `color` · `className`

**`<wa-icon>`는 Shadow DOM에 그린다.** 라이트 DOM을 직접 건드리면 React 등 가상 DOM 라이브러리와 자식 노드 소유권이 충돌해 `removeChild` 예외가 난다. shadow root는 프레임워크에 보이지 않고, `color`/`stroke-width` 같은 상속 속성은 경계를 그대로 통과한다.

### 굵기 오버라이드
```css
svg.wa-icon { stroke-width: var(--wa-stroke, 1.5); }
```
`--wa-stroke`를 조상에 선언하면 전역 조정된다. 프로덕션에서는 **1.5를 벗어나지 않는다** — 이 훅은 검수용이다.

---

## 5. 글리프 추가 절차

1. `docs/DESIGN_DOCTRINE.md` §4 규격 재확인
2. `G` 객체의 **해당 패밀리 블록 안에** 추가 (알파벳순 아님 — 티어 순서로)
3. 아이템용이면 `ITEM`에 `item_N: ['글리프-id', '한글 라벨']` 추가
4. 시스템용이면 `SYS_LABEL`에 라벨 추가
5. `WAIcons.audit().pass === true` 확인
6. `Icon Foundry.dc.html` 에서 육안 검수 — 16px에서 무너지지 않는지, 같은 패밀리와 시각 무게가 맞는지

새 패밀리를 만들면 `FAMILY_LABEL`과 스펙시멘 로직의 `order` 배열에도 추가한다.

---

## 6. 원본 게임 통합 (P7 · 미승인)

`ui.js`의 이모지 참조 4곳을 교체하면 끝난다. 원본 구조를 바꾸지 않는다.

```html
<!-- index.html — data.js 앞에 1행 추가 -->
<script src="icons/wa-icons.js"></script>
```

```js
// ui.js renderInventory / renderShop — item.icon → WAIcons.forItem
<h4>${WAIcons.forItem(item.id, { size: 20 })} ${item.name} ...</h4>

// ui.js renderOffice — innerText 대신 innerHTML
div.innerHTML = WAIcons.forItem(item.id, { size: 30 });
div.style.color = WAIcons.RARITY[item.rarity].color;   // 등급이 잉크에 실린다

// ui.js renderSets — 세트 필요 아이템 목록
`<span ...>${WAIcons.forItem(id, { size: 16 })}</span>`
```

```js
// data.js — 등급 색 교정 (D-05). rarities를 아래로 교체
const rarities = Object.freeze(WAIcons.RARITY);
```

`item.icon`(이모지) 필드는 롤백 대비로 **한 사이클 남겨둔 뒤** 제거한다.

**주의**: `renderOffice()`의 `.draggable-item`은 `font-size: 28px`로 이모지 크기를 잡고 있다.
아이콘으로 바꾸면 이 규칙은 무의미해지므로 CSS에서 `font-size`를 걷고 SVG 크기로 제어한다.

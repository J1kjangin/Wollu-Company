/* icons/wa-icons.js
 * Workspace Architect — 자체 아이콘 패밀리 "CYANOTYPE"
 * 규격: docs/DESIGN_DOCTRINE.md §4 — viewBox 0 0 24 24 · stroke 1.5 · linecap square · 정투상
 * 런타임: classic script. window.WAIcons + <wa-icon> 커스텀 엘리먼트.
 * file:// 직접 실행 호환 (ES Module / fetch / 외부 의존 없음).
 */
window.WAIcons = (function () {
    'use strict';

    /* ── 글리프 레지스트리 ────────────────────────────────────────────────
     * 값은 <svg> 내부 마크업. fill 없음, stroke는 currentColor 상속.
     * 티어 변형은 "반복과 확장"으로 표현 (교리 §4). */
    const G = {
        /* sys — 시스템 / UI (14) */
        'sys-logo':      '<rect x="3.5" y="3.5" width="17" height="17"/><path d="M3.5 20.5 20.5 3.5"/><path d="M3.5 9.5h6v-6"/>',
        'sys-decor':     '<path d="M3.5 3.5h17v9M20.5 16.5v4h-17v-17"/><rect x="6.5" y="12.5" width="6" height="5"/>',
        'sys-shop':      '<path d="M4.5 8.5h15l-1.5 11h-12z"/><path d="M9 8.5v-2a3 3 0 0 1 6 0v2"/>',
        'sys-sets':      '<rect x="3.5" y="7.5" width="10" height="10"/><path d="M6.5 7.5v-3h10v10h-3"/><path d="M9.5 4.5v-3h10v10h-3"/>',
        'sys-rank':      '<path d="M4.5 19.5h4v-6h-4zM10.5 19.5h4v-10h-4zM16.5 19.5h4v-14h-4z"/>',
        'sys-point':     '<circle cx="12" cy="12" r="8.5"/><path d="M9.5 16.5v-9h3.5a2.5 2.5 0 0 1 0 5H9.5"/>',
        'sys-rate':      '<path d="M5.5 14.5 12 8l6.5 6.5"/><path d="M5.5 19.5h13"/>',
        'sys-resign':    '<path d="M6.5 3.5h8l4 4v13h-12z"/><path d="M14.5 3.5v4h4"/><path d="M12 10.5v6"/><path d="M9.5 14l2.5 2.5 2.5-2.5"/>',
        'sys-rebirth':   '<path d="M20 12a8 8 0 1 1-3.2-6.4"/><path d="M20.5 4.5v5h-5"/>',
        'sys-close':     '<path d="M6 6l12 12M18 6L6 18"/>',
        'sys-check':     '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
        'sys-lock':      '<rect x="5.5" y="10.5" width="13" height="9"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/>',
        'sys-stamp':     '<rect x="3.5" y="6.5" width="17" height="11" rx="1"/><path d="M6.5 9.5h11M6.5 14.5h7"/>',
        'sys-grid':      '<rect x="3.5" y="3.5" width="17" height="17"/><path d="M9.17 3.5v17M14.83 3.5v17M3.5 9.17h17M3.5 14.83h17"/>',

        /* desk — 책상 (4) · 티어축: 천판 두께 → 서랍 → 양측 하부장 */
        'desk-basic':    '<path d="M2.5 8.5h19v2.5h-19z"/><path d="M5.5 11v7.5M18.5 11v7.5"/>',
        'desk-oak':      '<path d="M2.5 7.5h19v4h-19z"/><path d="M5.5 11.5v7M18.5 11.5v7"/><path d="M5 9.5h4.5M12 9.5h4.5"/>',
        'desk-white':    '<path d="M2.5 7.5h19v3h-19z"/><path d="M4.5 10.5v8M19.5 10.5v8"/><rect x="11.5" y="12.5" width="7" height="4"/><path d="M13.5 14.5h3"/>',
        'desk-exec':     '<path d="M1.5 7.5h21v3h-21z"/><path d="M3.5 10.5v9h17v-9"/><path d="M8.5 10.5v9M15.5 10.5v9"/>',

        /* seat — 의자 (5) · 등받이는 좌판보다 좁고, 발끝(feet)으로 착지를 명시 */
        'seat-basic':    '<rect x="8.5" y="3.5" width="7" height="6" rx="1"/><path d="M12 9.5v2"/><rect x="5.5" y="11.5" width="13" height="2.5"/><path d="M8 14v5M16 14v5"/><path d="M6.5 19.5h3M14.5 19.5h3"/>',
        'seat-cushion':  '<rect x="7.5" y="3.5" width="9" height="7" rx="2"/><path d="M9.5 7h5"/><path d="M12 10.5v1"/><rect x="4.5" y="11.5" width="15" height="4" rx="1.5"/><path d="M12 15.5v3"/><path d="M8 18.5h8"/>',
        'seat-swivel':   '<rect x="8.5" y="3.5" width="7" height="6" rx="1"/><path d="M12 9.5v1.5"/><rect x="5.5" y="11" width="13" height="2.5"/><path d="M4.5 11V9M19.5 11V9"/><path d="M12 13.5v4"/><path d="M5.5 20.5 12 17.5l6.5 3"/>',
        'seat-exec':     '<rect x="7.5" y="2.5" width="9" height="3" rx="1"/><rect x="8" y="5.5" width="8" height="5.5" rx="1"/><path d="M12 11v1"/><rect x="5" y="12" width="14" height="2.5"/><path d="M4 12V9.5M20 12V9.5"/><path d="M12 14.5v3.5"/><path d="M5 20.5 12 18l7 2.5"/>',
        'seat-meeting':  '<rect x="2.5" y="4.5" width="4.5" height="5" rx="1"/><rect x="9.75" y="4.5" width="4.5" height="5" rx="1"/><rect x="17" y="4.5" width="4.5" height="5" rx="1"/><rect x="1.5" y="11.5" width="21" height="2.5"/><path d="M4 14v5M12 14v5M20 14v5"/>',

        /* note — 노트 / 서식 (4) */
        'note-plain':    '<rect x="5.5" y="3.5" width="13" height="17"/><path d="M8.5 3.5v17"/>',
        'note-ruled':    '<rect x="5.5" y="3.5" width="13" height="17"/><path d="M8.5 3.5v17"/><path d="M10.5 8h6M10.5 11.5h6M10.5 15h4"/>',
        'note-diary':    '<rect x="4.5" y="3.5" width="15" height="17" rx="1"/><path d="M7.5 3.5v17"/><path d="M15.5 3.5v17"/><path d="M19.5 10.5h-4v3h4"/>',
        'note-memo':     '<rect x="5.5" y="6.5" width="13" height="13"/><path d="M8 6.5V4h13v13h-2.5"/><path d="M8.5 10.5h7M8.5 14.5h5"/>',

        /* pen — 필기구 (3) */
        'pen-pencil':    '<path d="M4.5 19.5l1.5-4.5L16.5 4.5l3 3L9 18z"/><path d="M6 15l3 3"/><path d="M14.5 6.5l3 3"/>',
        'pen-ball':      '<path d="M9.5 3.5h5v13l-2.5 4-2.5-4z"/><path d="M9.5 8.5h5"/><path d="M15.5 4.5v6"/>',
        'pen-marker':    '<rect x="8" y="3.5" width="8" height="10"/><path d="M9.5 13.5h5l1.5 7h-8z"/><path d="M8 7.5h8"/>',

        /* deco — 장식 (8) */
        'deco-calendar': '<rect x="4.5" y="6.5" width="15" height="11"/><path d="M4.5 10.5h15"/><path d="M8.5 6.5V4M15.5 6.5V4"/><path d="M8 13.5h3M13 13.5h3"/>',
        'deco-candle':   '<rect x="7.5" y="11.5" width="9" height="8"/><path d="M12 11.5V9"/><path d="M12 9c-1.5-1.5-1.5-3 0-4.5 1.5 1.5 1.5 3 0 4.5z"/><path d="M9 15h6"/>',
        'deco-plate':    '<rect x="4.5" y="7.5" width="15" height="8"/><path d="M7 10.5h10M7 12.5h6"/><path d="M2.5 19.5h19l-2-4h-15z"/>',
        'deco-plate-gold':'<rect x="4.5" y="7.5" width="15" height="8"/><rect x="6.5" y="9.5" width="11" height="4"/><path d="M8.5 11.5h7"/><path d="M2.5 19.5h19l-2-4h-15z"/>',
        'deco-badge':    '<rect x="9.5" y="2.5" width="5" height="3"/><path d="M11 5.5l-2 3M13 5.5l2 3"/><rect x="5.5" y="8.5" width="13" height="11" rx="1"/><rect x="8.5" y="12" width="3" height="4"/><path d="M13 12h3M13 15h3"/>',
        'deco-rug':      '<rect x="2.5" y="7.5" width="19" height="11"/><rect x="5.5" y="10.5" width="13" height="5"/><path d="M2.5 6V4.5M7 6V4.5M11.5 6V4.5M16 6V4.5M20.5 6V4.5"/>',
        'deco-frame':    '<rect x="3.5" y="4.5" width="17" height="15"/><rect x="6.5" y="7.5" width="11" height="9"/><path d="M6.5 16.5 10.5 11l3 3.5 2.5-3 1.5 2"/>',
        'deco-trophy':   '<path d="M8 3.5h8v5a4 4 0 0 1-8 0z"/><path d="M8 5.5H5.5v2a2.5 2.5 0 0 0 2.5 2.5M16 5.5h2.5v2a2.5 2.5 0 0 1-2.5 2.5"/><path d="M12 12.5v3"/><path d="M6.5 20.5h11v-3h-11z"/>',
        'deco-logowall': '<rect x="2.5" y="3.5" width="19" height="17"/><path d="M2.5 8.5h19"/><rect x="9.5" y="11.5" width="5" height="5"/><path d="M9.5 16.5 14.5 11.5"/>',

        /* store — 수납 (8) · 티어축: 단 수 → 폭 → 유리문 */
        'store-folder':  '<path d="M3.5 6.5h6.5l2 3h8.5v10h-17z"/><path d="M3.5 11.5h17"/>',
        'store-tray':    '<path d="M3.5 12.5l3-4h11l3 4v6h-17z"/><path d="M3.5 12.5h17"/>',
        'store-tray-3':  '<path d="M3.5 5.5h17v4h-17zM3.5 10.5h17v4h-17zM3.5 15.5h17v4h-17z"/><path d="M8 7.5h8M8 12.5h8M8 17.5h8"/>',
        'store-cabinet': '<rect x="4.5" y="3.5" width="15" height="17"/><path d="M12 3.5v17"/><path d="M10.5 10.5v3M13.5 10.5v3"/>',
        'store-cabinet-pro':'<rect x="3.5" y="2.5" width="17" height="17"/><path d="M3.5 7h17M3.5 11.5h17M3.5 16h17"/><path d="M10.5 4.75h3M10.5 9.25h3M10.5 13.75h3"/><path d="M5 19.5v1.5M19 19.5v1.5"/>',
        'store-shelf':   '<rect x="4.5" y="3.5" width="15" height="17"/><path d="M4.5 9h15M4.5 14.5h15"/><path d="M7 5.5v3.5M9.5 5.5v3.5M12 5.5v3.5"/><path d="M7 11v3.5M9.5 11v3.5"/>',
        'store-shelf-xl':'<rect x="1.5" y="2.5" width="21" height="19"/><path d="M1.5 7h21M1.5 12h21M1.5 17h21"/><path d="M4 3.5v3.5M6.5 3.5v3.5M9 3.5v3.5M14 3.5v3.5M16.5 3.5v3.5"/><path d="M4 8.5v3.5M6.5 8.5v3.5M4 13.5v3.5"/>',
        'store-shelf-exec':'<rect x="2.5" y="5.5" width="19" height="15"/><path d="M1.5 5.5h21"/><path d="M12 5.5v15"/><path d="M2.5 11h19M2.5 16h19"/><rect x="4.5" y="2.5" width="15" height="3"/>',

        /* pc — 컴퓨터 (15) · 티어축: 화면 폭 / 키 행 / 실루엣 */
        'pc-monitor':    '<rect x="5.5" y="4.5" width="13" height="10"/><path d="M12 14.5v3"/><path d="M8.5 20.5h7"/>',
        'pc-monitor-wide':'<rect x="2.5" y="5.5" width="19" height="9"/><path d="M12 14.5v3"/><path d="M8 20.5h8"/>',
        'pc-monitor-dual':'<rect x="1.5" y="5.5" width="10" height="8"/><rect x="12.5" y="5.5" width="10" height="8"/><path d="M6.5 13.5v3M17.5 13.5v3"/><path d="M3.5 19.5h6M14.5 19.5h6"/>',
        'pc-monitor-ultra':'<path d="M1.5 6.5c7-1 14-1 21 0v7.5c-7 1-14 1-21 0z"/><path d="M12 15v3.5"/><path d="M7.5 20.5h9"/>',
        'pc-keyboard':   '<rect x="2.5" y="8.5" width="19" height="8"/><path d="M5 11.5h14M5 14h9"/>',
        'pc-keyboard-mech':'<rect x="2.5" y="7.5" width="19" height="10"/><path d="M5 10.5h14M5 13h14M5 15.5h9"/>',
        'pc-keyboard-silent':'<rect x="2.5" y="8.5" width="19" height="8" rx="2.5"/><path d="M5.5 12h13M5.5 14.5h8"/>',
        'pc-keyboard-wireless':'<rect x="2.5" y="11.5" width="19" height="7" rx="1"/><path d="M5 14.5h14M5 16.5h9"/><path d="M9.5 7.5a4 4 0 0 1 5 0M7.5 4.5a8 8 0 0 1 9 0"/>',
        'pc-mouse':      '<path d="M12 4.5a6 6 0 0 1 6 6v5a4.5 4.5 0 0 1-4.5 4.5h-3A4.5 4.5 0 0 1 6 15.5v-5a6 6 0 0 1 6-6z"/><path d="M12 4.5v6"/>',
        'pc-mouse-wireless':'<path d="M12 6.5a5.5 5.5 0 0 1 5.5 5.5v4a4 4 0 0 1-4 4h-3a4 4 0 0 1-4-4v-4A5.5 5.5 0 0 1 12 6.5z"/><path d="M12 6.5v5"/><path d="M9 3.5a5 5 0 0 1 6 0"/>',
        'pc-mouse-ergo': '<path d="M11 4.5a6 6 0 0 1 6 6v5a4.5 4.5 0 0 1-4.5 4.5h-2A4.5 4.5 0 0 1 6 15.5v-4"/><path d="M6 11.5 3.5 13v3.5L6 15.5"/><path d="M11 4.5v6"/>',
        'pc-mouse-pro':  '<path d="M12 5.5a5.5 5.5 0 0 1 5.5 5.5v4.5A4.5 4.5 0 0 1 13 20h-2a4.5 4.5 0 0 1-4.5-4.5V11A5.5 5.5 0 0 1 12 5.5z"/><path d="M12 5.5v4"/><path d="M12 10.5v2.5"/><path d="M6.5 13.5h2M6.5 16h2"/>',
        'pc-pad':        '<rect x="4.5" y="8.5" width="15" height="8" rx="1"/><path d="M13 10.5a2 2 0 0 1 2 2v1a1.5 1.5 0 0 1-1.5 1.5h-1a1.5 1.5 0 0 1-1.5-1.5v-1a2 2 0 0 1 2-2z"/>',
        'pc-pad-xl':     '<rect x="1.5" y="6.5" width="21" height="11" rx="1"/><path d="M15.5 9.5a2.5 2.5 0 0 1 2.5 2.5v1.5a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2V12a2.5 2.5 0 0 1 2.5-2.5z"/><rect x="4.5" y="9.5" width="6" height="5"/>',
        'pc-headset':    '<path d="M5.5 14v-2a6.5 6.5 0 0 1 13 0v2"/><rect x="3.5" y="13.5" width="4" height="7" rx="1"/><rect x="16.5" y="13.5" width="4" height="7" rx="1"/>',

        /* cup — 음료 (6) */
        'cup-tumbler':   '<path d="M7.5 6.5h9l-1.5 13h-6z"/><rect x="6.5" y="3.5" width="11" height="3"/>',
        'cup-tumbler-steel':'<path d="M7.5 6.5h9l-1.5 13h-6z"/><rect x="6.5" y="3.5" width="11" height="3"/><path d="M10.5 8v10M13.5 8v10"/>',
        'cup-tumbler-pro':'<path d="M7.5 6.5h9l-1.5 13h-6z"/><rect x="6" y="3.5" width="12" height="3"/><path d="M7 11.5h10"/><path d="M18 8a3 3 0 0 1 0 5"/>',
        'cup-mug':       '<rect x="4.5" y="7.5" width="11" height="11"/><path d="M15.5 10.5h3a2.5 2.5 0 0 1 0 5h-3"/>',
        'cup-mug-logo':  '<rect x="4.5" y="7.5" width="11" height="11"/><path d="M15.5 10.5h3a2.5 2.5 0 0 1 0 5h-3"/><rect x="7.5" y="11" width="5" height="4"/>',
        'cup-set':       '<rect x="3.5" y="8.5" width="7" height="5"/><path d="M10.5 9.5h2a1.5 1.5 0 0 1 0 3h-2"/><path d="M1.5 15.5h11"/><rect x="14.5" y="11.5" width="6" height="5"/><path d="M20.5 12.5h1a1.2 1.2 0 0 1 0 2.4h-1"/><path d="M13 18.5h9"/>',

        /* app — 가전 (5) */
        'app-purifier':  '<rect x="7.5" y="4.5" width="9" height="16" rx="1"/><path d="M9.5 8h5M9.5 10.5h5M9.5 13h5"/><path d="M12 16.5v2"/><path d="M4.5 6.5a3 3 0 0 1 0 4M19.5 6.5a3 3 0 0 0 0 4"/>',
        'app-fridge':    '<rect x="5.5" y="2.5" width="13" height="18" rx="1"/><path d="M5.5 9h13"/><path d="M15.5 5v3M15.5 11v3"/>',
        'app-microwave': '<rect x="2.5" y="7.5" width="19" height="10" rx="1"/><rect x="5" y="10" width="9" height="5"/><path d="M16.5 10h3M16.5 12.5h3M16.5 15h3"/>',
        'app-coffeemaker':'<rect x="4.5" y="3.5" width="15" height="8"/><path d="M7.5 8h4"/><path d="M11.5 11.5v2"/><rect x="8.5" y="13.5" width="6" height="6"/><path d="M14.5 15h2v2h-2"/>',
        'app-coffeemaker-pro':'<rect x="3.5" y="2.5" width="17" height="9"/><path d="M6.5 5.5h4M13.5 5.5h4"/><path d="M9 11.5v2M15 11.5v2"/><rect x="6.5" y="13.5" width="5" height="6"/><rect x="12.5" y="13.5" width="5" height="6"/><path d="M3.5 20.5h17"/>',

        /* food — 식음 (2) */
        'food-jar':      '<rect x="6.5" y="8.5" width="11" height="11"/><rect x="5.5" y="5.5" width="13" height="3"/><path d="M9 12h6"/>',
        'food-bar':      '<path d="M2.5 19.5v-15h19v15z"/><path d="M2.5 9.5h19M2.5 14.5h19"/><rect x="5" y="6" width="3" height="3"/><rect x="11" y="11" width="3" height="3"/><rect x="16" y="16" width="3" height="3"/>',

        /* flora — 식물 (5) · 유기 곡선 허용 (교리 §4 예외) */
        'flora-pot':     '<path d="M7.5 14.5h9l-1.5 6h-6z"/><path d="M12 14.5v-3"/><path d="M12 11.5a4 4 0 0 0-4-4 4 4 0 0 0 4 4z"/><path d="M12 11.5a4 4 0 0 1 4-4 4 4 0 0 1-4 4z"/>',
        'flora-cactus':  '<path d="M8.5 16.5h7l-1 4h-5z"/><path d="M12 16.5V6"/><path d="M12 12.5H9.5a2 2 0 0 1-2-2V9"/><path d="M12 10.5h2.5a2 2 0 0 0 2-2V7"/>',
        'flora-large':   '<path d="M6.5 15.5h11l-2 5h-7z"/><path d="M12 15.5V8"/><path d="M12 8 8 4.5M12 8l4-3.5M12 11.5 7.5 9M12 11.5l4.5-2.5"/>',
        'flora-palm':    '<path d="M9.5 16.5h5l-1 4h-3z"/><path d="M12 16.5V9"/><path d="M12 9C9 9 6.5 6.5 6 4c2.5 1 4.5 2.5 6 5zM12 9c3 0 5.5-2.5 6-5-2.5 1-4.5 2.5-6 5z"/>',
        'flora-conifer': '<path d="M12 3.5 7.5 10h9zM12 8.5 5.5 16.5h13z"/><path d="M12 16.5v4"/><path d="M9.5 20.5h5"/>',

        /* lamp — 조명 (3) */
        'lamp-desk':     '<path d="M7.5 20.5h9"/><path d="M12 20.5V9.5"/><path d="M6.5 9.5 12 3l5.5 6.5z"/>',
        'lamp-arc':      '<path d="M3.5 20.5h8"/><path d="M7.5 20.5V15"/><path d="M7.5 15C7.5 7 12 4.5 18 4.5"/><path d="M14.5 4.5h7l-2 5h-3z"/>',
        'lamp-pendant':  '<path d="M12 2.5v5"/><path d="M4.5 15.5h15l-3.5-8h-8z"/><path d="M8 18.5h8"/>',

        /* time — 시계 (3) */
        'time-digital':  '<rect x="3.5" y="7.5" width="17" height="9" rx="1"/><rect x="6.5" y="10.5" width="3" height="3"/><rect x="11" y="10.5" width="3" height="3"/><rect x="15.5" y="10.5" width="3" height="3"/>',
        'time-wall':     '<circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3.5 2"/>',
        'time-large':    '<circle cx="12" cy="12" r="9.5"/><path d="M12 5.5v5.5l4 2.5"/><path d="M12 2.5V4M12 20v1.5M2.5 12H4M20 12h1.5"/>',

        /* eq — 사무기기 (10) */
        'eq-printer':    '<rect x="4.5" y="9.5" width="15" height="7"/><path d="M7.5 9.5V5.5h9v4"/><rect x="7.5" y="16.5" width="9" height="4"/><path d="M6.5 12h3"/>',
        'eq-printer-color':'<rect x="4.5" y="9.5" width="15" height="7"/><path d="M7.5 9.5V5.5h9v4"/><rect x="7.5" y="16.5" width="9" height="4"/><path d="M6.5 12.5h1.5M9.5 12.5H11M12.5 12.5H14M15.5 12.5H17"/>',
        'eq-mfp':        '<rect x="3.5" y="6.5" width="17" height="3"/><rect x="3.5" y="9.5" width="17" height="8"/><path d="M6.5 12.5h5M6.5 15h3"/><rect x="14.5" y="12.5" width="4" height="4"/><rect x="7.5" y="17.5" width="9" height="3"/>',
        'eq-phone':      '<rect x="3.5" y="13.5" width="17" height="6"/><rect x="5.5" y="9.5" width="5" height="3"/><path d="M6 12.5v1M9 12.5v1"/><path d="M13 15.5h5M13 17.5h5"/>',
        'eq-phone-pro':  '<rect x="3.5" y="11.5" width="17" height="9"/><rect x="5.5" y="7.5" width="5" height="3"/><path d="M6 10.5v1M9 10.5v1"/><rect x="12.5" y="13.5" width="6" height="2"/><path d="M6 15h1.5M9 15h1.5M6 17.5h1.5M9 17.5h1.5M12.5 17.5h6"/>',
        'eq-corkboard':  '<rect x="2.5" y="4.5" width="19" height="15"/><rect x="5.5" y="7.5" width="6" height="5"/><rect x="13.5" y="9.5" width="5" height="7"/><path d="M8.5 7.5v-1M16 9.5v-1"/>',
        'eq-board':      '<rect x="2.5" y="4.5" width="19" height="12"/><path d="M6 8h8M6 11h5"/><path d="M4.5 16.5h15v2h-15z"/>',
        'eq-board-xl':   '<rect x="1.5" y="3.5" width="21" height="13"/><path d="M5 7h11M5 10h7M5 13h9"/><path d="M4 16.5v4M20 16.5v4"/>',
        'eq-tv':         '<rect x="1.5" y="4.5" width="21" height="12"/><path d="M12 16.5v3"/><path d="M7.5 19.5h9"/>',
        'eq-tv-wall':    '<rect x="1.5" y="3.5" width="21" height="14"/><path d="M4.5 7h8M4.5 10h5"/><rect x="14.5" y="6.5" width="5" height="4"/><path d="M12 17.5v2"/>',
        'eq-videoconf':  '<rect x="2.5" y="7.5" width="19" height="11" rx="1"/><circle cx="8.5" cy="12" r="2.5"/><path d="M14 10.5h4.5M14 13.5h4.5"/><rect x="10" y="4.5" width="4" height="3"/><path d="M11.5 6h1"/>',
        'eq-speaker':    '<rect x="6.5" y="2.5" width="11" height="19" rx="1"/><circle cx="12" cy="8" r="3"/><circle cx="12" cy="16" r="2"/>',

        /* sofa — 소파 (3) · 등받이 상단 레일 + 팔걸이 + 인셋된 라운드 쿠션. 티어축: 쿠션 분할 수 */
        'sofa-1':        '<rect x="4.5" y="5.5" width="15" height="6" rx="1"/><path d="M4.5 8h15"/><rect x="2.5" y="11" width="4" height="7" rx="1"/><rect x="17.5" y="11" width="4" height="7" rx="1"/><rect x="6.5" y="12.5" width="11" height="5" rx="1"/><path d="M4 18v2M20 18v2"/>',
        'sofa-2':        '<rect x="3.5" y="5.5" width="17" height="6" rx="1"/><path d="M3.5 8h17"/><rect x="1.5" y="11" width="3.5" height="7" rx="1"/><rect x="19" y="11" width="3.5" height="7" rx="1"/><rect x="5.5" y="12.5" width="13" height="5" rx="1"/><path d="M12 12.5v5"/><path d="M3 18v2M21 18v2"/>',
        'sofa-3':        '<rect x="2.5" y="5.5" width="19" height="6" rx="1"/><path d="M2.5 8h19"/><rect x="1.5" y="11" width="2.5" height="7" rx="1"/><rect x="20" y="11" width="2.5" height="7" rx="1"/><rect x="4.5" y="12.5" width="15" height="5" rx="1"/><path d="M9.5 12.5v5M14.5 12.5v5"/><path d="M2.75 18v2M21.25 18v2"/>',

        /* table — 테이블 (3) */
        'table-meeting': '<path d="M1.5 8.5h21v3h-21z"/><path d="M4.5 11.5v8M19.5 11.5v8"/><path d="M4.5 15.5h15"/>',
        'table-coffee':  '<path d="M2.5 13.5h19v2h-19z"/><path d="M5.5 15.5v4M18.5 15.5v4"/><rect x="8.5" y="8.5" width="5" height="5"/><path d="M13.5 9.5h2a1.5 1.5 0 0 1 0 3h-2"/>',
        'table-conference':'<path d="M1.5 9.5h21v3h-21z"/><path d="M3.5 12.5v7M8.5 12.5v7M15.5 12.5v7M20.5 12.5v7"/><path d="M3.5 16h17"/>',

        /* space — 공간 / 엔드게임 (10) */
        'space-office':      '<rect x="4.5" y="3.5" width="15" height="17"/><path d="M7.5 6.5h9v14h-9z"/><path d="M14 13h1.5"/><rect x="10" y="8.5" width="4" height="2"/>',
        'space-glasswall':   '<rect x="2.5" y="3.5" width="19" height="17"/><path d="M8.83 3.5v17M15.17 3.5v17"/><path d="M2.5 12h19"/><path d="M4.5 5.5 7 8"/>',
        'space-lounge':      '<path d="M2.5 11.5h11v3h-11z"/><path d="M2.5 14.5h2v5h-2zM11.5 14.5h2v5h-2z"/><path d="M4.5 14.5h7v5h-7z"/><path d="M18 19.5V9"/><path d="M14.5 9 18 4.5 21.5 9z"/><path d="M15.5 19.5h5"/>',
        'space-cafe':        '<path d="M2.5 15.5h19v5h-19z"/><path d="M4.5 18h5"/><rect x="6.5" y="6.5" width="7" height="6"/><path d="M8 12.5v3"/><rect x="15.5" y="9.5" width="4" height="3"/><path d="M19.5 10.5h1a1 1 0 0 1 0 2h-1"/>',
        'space-roofgarden':  '<path d="M1.5 13.5h21v2h-21z"/><path d="M3.5 15.5v5M20.5 15.5v5"/><path d="M5.5 20.5h5v-5h-5z"/><path d="M8 15.5V9"/><path d="M4.5 9a3.5 3.5 0 0 1 7 0z"/><path d="M14 20.5h5v-5h-5z"/><path d="M16.5 15.5v-3"/><path d="M14 12.5a2.5 2.5 0 0 1 5 0z"/>',
        'space-meetingroom': '<rect x="2.5" y="3.5" width="19" height="17"/><path d="M2.5 8.5h19"/><path d="M8.5 3.5v5M15.5 3.5v5"/><rect x="7.5" y="12.5" width="9" height="4" rx="1"/><path d="M5 13h2v3H5zM17 13h2v3h-2z"/>',
        'space-penthouse':   '<path d="M4.5 20.5v-9h15v9z"/><path d="M7.5 11.5v-4h9v4"/><path d="M2.5 20.5h19"/><rect x="9" y="14" width="6" height="6"/><path d="M12 14v6"/>',
        'space-lobby':       '<path d="M2.5 20.5V6.5h19v14"/><path d="M2.5 6.5 12 2.5l9.5 4"/><path d="M6.5 20.5v-8h11v8"/><path d="M12 12.5v8"/><path d="M9 16h1.5M13.5 16H15"/>',
        'space-tower':       '<path d="M6.5 20.5V4.5h11v16"/><path d="M9 7h2M13 7h2M9 10h2M13 10h2M9 13h2M13 13h2M9 16h2M13 16h2"/><path d="M3.5 20.5h17"/><path d="M12 4.5V1.5"/>',
        'space-hq':          '<path d="M1.5 20.5V11h6v9M8.5 20.5V4.5h7v16M16.5 20.5V8h6v12.5"/><rect x="10.5" y="8" width="3" height="3"/><path d="M10.5 11 13.5 8"/><path d="M.5 20.5h23"/>',
    };

    /* ── 아이템 매핑 ──────────────────────────────────────────────────────
     * item_N: [글리프 id, 한글 라벨(aria-label / 스펙시멘용)]
     * 원본 data.js 의 100종과 1:1. 충돌 0 · 오배정 0 (docs/ANALYSIS.md D-01/D-02 해소) */
    const ITEM = {
        item_1:['desk-basic','기본 책상'], item_2:['desk-oak','원목 책상'], item_3:['desk-white','화이트 책상'],
        item_4:['seat-basic','기본 사무용 의자'], item_5:['seat-cushion','푹신한 의자'], item_6:['seat-swivel','회전 의자'],
        item_7:['note-plain','노트'], item_8:['note-ruled','업무 노트'], item_9:['note-diary','다이어리'],
        item_10:['pen-pencil','연필 세트'], item_11:['pen-ball','볼펜 세트'], item_12:['pen-marker','형광펜 세트'],
        item_13:['deco-calendar','책상 달력'], item_14:['store-folder','서류철'], item_15:['note-memo','메모지'],

        item_16:['pc-monitor','기본 모니터'], item_17:['pc-monitor-wide','와이드 모니터'],
        item_18:['pc-monitor-dual','듀얼 모니터'], item_19:['pc-monitor-ultra','울트라와이드 모니터'],
        item_20:['pc-keyboard','기본 키보드'], item_21:['pc-keyboard-mech','기계식 키보드'],
        item_22:['pc-keyboard-silent','저소음 키보드'], item_23:['pc-keyboard-wireless','무선 키보드'],
        item_24:['pc-mouse','기본 마우스'], item_25:['pc-mouse-wireless','무선 마우스'],
        item_26:['pc-mouse-ergo','인체공학 마우스'], item_27:['pc-mouse-pro','고급 마우스'],
        item_28:['pc-pad','마우스패드'], item_29:['pc-pad-xl','대형 마우스패드'], item_30:['pc-headset','헤드셋'],

        item_31:['cup-tumbler','기본 텀블러'], item_32:['cup-tumbler-steel','스테인리스 텀블러'],
        item_33:['cup-tumbler-pro','고급 텀블러'], item_34:['cup-mug','머그컵'],
        item_35:['cup-mug-logo','회사 로고 머그컵'], item_36:['cup-set','커피잔 세트'],
        item_37:['flora-pot','작은 화분'], item_38:['flora-cactus','선인장'], item_39:['flora-large','대형 화분'],
        item_40:['lamp-desk','책상 스탠드'], item_41:['lamp-arc','고급 스탠드'],
        item_42:['time-digital','디지털 시계'], item_43:['time-wall','벽시계'],
        item_44:['deco-candle','향초'], item_45:['food-jar','간식통'],

        item_46:['store-tray','서류함'], item_47:['store-tray-3','3단 서류함'],
        item_48:['store-cabinet','캐비닛'], item_49:['store-cabinet-pro','고급 캐비닛'],
        item_50:['store-shelf','책장'], item_51:['store-shelf-xl','대형 책장'],
        item_52:['eq-printer','프린터'], item_53:['eq-printer-color','컬러 프린터'], item_54:['eq-mfp','복합기'],
        item_55:['eq-phone','유선 전화기'], item_56:['eq-phone-pro','사무용 전화기'],
        item_57:['deco-plate','명패'], item_58:['deco-badge','사원증 거치대'],
        item_59:['eq-corkboard','코르크 게시판'], item_60:['eq-board','화이트보드'],

        item_61:['sofa-1','1인 소파'], item_62:['sofa-2','2인 소파'], item_63:['sofa-3','3인 소파'],
        item_64:['table-meeting','회의 테이블'], item_65:['table-coffee','커피 테이블'],
        item_66:['eq-tv','대형 TV'], item_67:['app-purifier','공기청정기'], item_68:['app-fridge','냉장고'],
        item_69:['app-microwave','전자레인지'], item_70:['app-coffeemaker','커피머신'],

        item_71:['desk-exec','CEO 스타일 책상'], item_72:['seat-exec','대형 CEO 의자'],
        item_73:['store-shelf-exec','차장실 대형 책장'], item_74:['lamp-pendant','고급 조명'],
        item_75:['deco-rug','사무실 러그'], item_76:['flora-palm','차장실 화분'],
        item_77:['deco-frame','그림 액자'], item_78:['deco-trophy','트로피'],
        item_79:['deco-plate-gold','금색 명패'], item_80:['app-coffeemaker-pro','고급 커피머신'],

        item_81:['table-conference','회의실 테이블'], item_82:['seat-meeting','회의용 의자 세트'],
        item_83:['eq-board-xl','대형 화이트보드'], item_84:['eq-tv-wall','회의용 TV'],
        item_85:['eq-videoconf','화상회의 장비'], item_86:['eq-speaker','회의실 스피커'],
        item_87:['flora-conifer','회의실 식물'], item_88:['time-large','회의실 대형 시계'],
        item_89:['deco-logowall','회사 로고 벽면'], item_90:['food-bar','회의실 간식바'],

        item_91:['space-office','개인 사무실'], item_92:['space-glasswall','통유리 벽'],
        item_93:['space-lounge','CEO 라운지'], item_94:['space-cafe','개인 카페'],
        item_95:['space-roofgarden','옥상 정원'], item_96:['space-meetingroom','전용 회의실'],
        item_97:['space-penthouse','펜트하우스 사장실'], item_98:['space-lobby','오피스 사옥 로비'],
        item_99:['space-tower','오피스 타워'], item_100:['space-hq','아키텍처 본사'],
    };

    const SYS_LABEL = {
        'sys-logo':'아키텍트 마크', 'sys-decor':'꾸미기', 'sys-shop':'상점', 'sys-sets':'세트',
        'sys-rank':'직급', 'sys-point':'포인트', 'sys-rate':'초당 생산성', 'sys-resign':'사직서',
        'sys-rebirth':'환생', 'sys-close':'닫기', 'sys-check':'완료', 'sys-lock':'미해금',
        'sys-stamp':'결재 도장', 'sys-grid':'격자',
    };

    const FAMILY_LABEL = {
        sys:'시스템', desk:'책상', seat:'의자', note:'노트·서식', pen:'필기구', deco:'장식',
        store:'수납', pc:'컴퓨터', cup:'음료', app:'가전', food:'식음', flora:'식물',
        lamp:'조명', time:'시계', eq:'사무기기', sofa:'소파', table:'테이블', space:'공간',
    };

    /* 등급 스케일 — docs/DESIGN_DOCTRINE.md §2 (D-05 교정) */
    const RARITY = {
        normal:    { name:'일반', color:'oklch(0.68 0.015 265)', hex:'#9aa0ab' },
        advanced:  { name:'고급', color:'oklch(0.72 0.13 152)',  hex:'#3ec27e' },
        rare:      { name:'희귀', color:'oklch(0.74 0.15 245)',  hex:'#4aa8f0' },
        legendary: { name:'전설', color:'oklch(0.76 0.17 305)',  hex:'#b98cff' },
        mythic:    { name:'신화', color:'oklch(0.84 0.17 88)',   hex:'#f0c33c' },
    };

    /* ── 렌더러 ─────────────────────────────────────────────────────────── */
    const ATTRS = 'viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="square" stroke-linejoin="miter"';

    function has(name) { return Object.prototype.hasOwnProperty.call(G, name); }

    /** 글리프 id → <svg> 문자열. 없는 id는 격자 플레이스홀더를 돌려주고 경고한다. */
    function svg(name, opts) {
        const o = opts || {};
        const size = o.size || 24;
        const label = o.label;
        const found = has(name);
        if (!found) console.warn('[WAIcons] 미등록 글리프:', name);
        const body = found ? G[name] : G['sys-grid'];
        const a11y = label
            ? ' role="img" aria-label="' + String(label).replace(/"/g, '&quot;') + '"'
            : ' aria-hidden="true"';
        const style = o.color ? ' style="color:' + o.color + '"' : '';
        const cls = ' class="wa-icon' + (o.className ? ' ' + o.className : '') + '"';
        return '<svg ' + ATTRS + ' width="' + size + '" height="' + size + '"' + cls + a11y + style + '>' + body + '</svg>';
    }

    /** 아이템 id(item_7) → <svg>. 라벨은 자동으로 붙는다. */
    function forItem(itemId, opts) {
        const e = ITEM[itemId];
        if (!e) { console.warn('[WAIcons] 미매핑 아이템:', itemId); return svg('sys-grid', opts); }
        const o = Object.assign({ label: e[1] }, opts || {});
        return svg(e[0], o);
    }

    function glyphOf(itemId) { return ITEM[itemId] ? ITEM[itemId][0] : null; }
    function labelOf(name) {
        if (SYS_LABEL[name]) return SYS_LABEL[name];
        for (const k in ITEM) if (ITEM[k][0] === name) return ITEM[k][1];
        return name;
    }
    function familyOf(name) { return name.split('-')[0]; }

    /** 패밀리별 글리프 목록 (스펙시멘용) */
    function families() {
        const out = {};
        for (const name in G) {
            const f = familyOf(name);
            (out[f] = out[f] || []).push(name);
        }
        return out;
    }

    /* ── 자체 감사 (P3 Gate G3-a/b/d 자동 검증) ─────────────────────────── */
    function audit() {
        const glyphs = Object.keys(G);
        const items = Object.keys(ITEM);
        const used = items.map(k => ITEM[k][0]);
        const missing = used.filter(g => !has(g));
        const seen = {}, collisions = [];
        used.forEach((g, i) => {
            if (seen[g] !== undefined) collisions.push([items[seen[g]], items[i], g]);
            else seen[g] = i;
        });
        const orphans = glyphs.filter(g => familyOf(g) !== 'sys' && used.indexOf(g) === -1);
        // 규격 위반 탐지: fill/stroke-width/그라디언트/텍스트 하드코딩
        const violations = glyphs.filter(g =>
            /fill="(?!none)/.test(G[g]) || /stroke-width/.test(G[g]) ||
            /<text|linearGradient|filter=/.test(G[g]));
        return {
            glyphCount: glyphs.length,
            itemCount: items.length,
            coverage: items.length - missing.length + '/' + items.length,
            missing, collisions, orphans, violations,
            pass: missing.length === 0 && collisions.length === 0 && violations.length === 0,
        };
    }

    /* ── <wa-icon name="desk-basic" size="24"> ────────────────────────────
     * Shadow DOM에 그린다. 이유: 라이트 DOM을 직접 건드리면 React 등
     * 가상 DOM 라이브러리와 자식 노드 소유권이 충돌한다(removeChild 예외).
     * shadow root는 프레임워크에 보이지 않으므로 안전하며, stroke/color 같은
     * 상속 속성은 shadow 경계를 그대로 통과한다. */
    if (typeof customElements !== 'undefined' && !customElements.get('wa-icon')) {
        class WAIconEl extends HTMLElement {
            static get observedAttributes() { return ['name', 'size', 'item', 'label']; }
            constructor() { super(); this._root = this.attachShadow({ mode: 'open' }); }
            connectedCallback() { this._paint(); }
            attributeChangedCallback() { if (this._root) this._paint(); }
            _paint() {
                const item = this.getAttribute('item');
                const size = this.getAttribute('size') || 24;
                const name = item ? glyphOf(item) : (this.getAttribute('name') || 'sys-grid');
                const label = this.getAttribute('label') || (name ? labelOf(name) : '');
                this._root.innerHTML =
                    '<style>:host{display:inline-flex;line-height:0;vertical-align:middle}' +
                    'svg{stroke-width:var(--wa-stroke,1.5)}</style>' +
                    svg(name || 'sys-grid', { size: size });
                this.setAttribute('role', 'img');
                if (label) this.setAttribute('aria-label', label);
            }
        }
        customElements.define('wa-icon', WAIconEl);
    }

    return {
        version: '1.0.0',
        glyphs: G, ITEM, RARITY, SYS_LABEL, FAMILY_LABEL,
        svg, forItem, glyphOf, labelOf, familyOf, families, has, audit,
    };
})();

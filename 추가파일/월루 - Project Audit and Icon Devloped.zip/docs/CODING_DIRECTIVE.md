# P5 · 코딩 스타일 디렉티브

> 규칙마다 **왜**와 **이 코드베이스의 실제 사례**를 붙였다. 일반론은 넣지 않았다.
> 판정 근거는 `docs/ANALYSIS.md`.

---

## 0. 절대 제약 (위반 시 앱이 실행조차 되지 않음)

| # | 규칙 | 왜 |
|---|---|---|
| C-1 | **빌드 스텝 도입 금지** | npm/bundler가 없는 프로젝트다. 도입하면 배포 방식 자체가 바뀐다 |
| C-2 | **`import`/`export` 금지. IIFE + `window.Workspace`** | `file://`에서 ES 모듈은 CORS로 차단된다. `data.js` 상단 주석이 이 결정을 명시하고 있다 |
| C-3 | **`fetch()` 금지** | 동일 이유. 데이터는 JS 리터럴로 인라인한다 |
| C-4 | **외부 CDN 필수 의존 금지** | 오프라인/로컬 실행이 요구사항. 웹폰트는 폴백이 있는 `<link>`까지만 |
| C-5 | **세이브 스키마 변경 시 `SAVE_VERSION` 상승 + 마이그레이션** | `load()`는 필드 단위 검증만 한다. 구조가 바뀌면 기존 플레이어의 진행이 소실된다 |

새 모듈 템플릿:
```js
// js/newModule.js
window.Workspace = window.Workspace || {};
(function (ns) {
    'use strict';
    const { CONFIG } = ns.data;      // 의존은 위에서 구조분해로 명시
    /* ... */
    ns.newThing = { /* 공개 표면만 */ };
})(window.Workspace);
```
`<script>` 순서는 의존 순서다: `data → gameState → dragAndDrop → ui → main`.

---

## 1. 레이어 규칙 — 이 코드베이스의 가장 잘 지켜진 자산

```
data.js       순수 데이터. 로직 0, DOM 0.
gameState.js  상태 + 규칙. DOM 0. (검증됨: `document` 참조 없음)
dragAndDrop.js 입력. 상태 0.
ui.js         렌더. 상태 변경 0.
main.js       조립 + 이벤트 위임. 유일한 접착층.
```

| # | 규칙 | 근거 |
|---|---|---|
| L-1 | **`gameState.js`에 `document`/`window` 접근을 절대 넣지 않는다** | 지금 없기 때문에 규칙을 테스트할 수 있고 UI를 갈아치울 수 있다. 한 줄이라도 들어가면 그 성질이 사라진다 |
| L-2 | **`ui.js`는 state를 읽기만 한다** | 단방향 흐름. 현재 준수 중 |
| L-3 | **`data.js`는 `Object.freeze`** | 이미 전면 적용됨. 파생 데이터도 freeze (`shopItems`의 `ITEM_BONUS_MULTIPLIER` 패턴이 정답) |
| L-4 | **전역 함수 금지. `data-action` 위임만** | `main.js`가 이미 그렇게 한다. `onclick="foo()"`를 추가하는 순간 `ui.js`가 전역에 결합된다 |
| L-5 | **`ns.state` 노출은 devtools 전용** | `main.js:18` 주석이 이미 선언한 계약이다. 프로덕션 코드에서 `Workspace.state`를 참조하면 조립 규칙이 무너진다 |

---

## 2. 렌더 규칙 — 현재 가장 심하게 위반된 영역

| # | 규칙 | 위반 사례 |
|---|---|---|
| R-1 | **`renderAll()`을 게임 루프에서 부르지 않는다** | `main.js:20` + `gameState.js:170`. tick마다 전체 DOM 재구축 (`R-01`) |
| R-2 | **`_notify`는 "무엇이 바뀌었는지" 를 전달한다** | 현재 `_notify()`는 인자가 없어 구독자가 전체 렌더밖에 할 수 없다 |
| R-3 | **스크롤 컨테이너의 자손을 `innerHTML=''`로 비우지 않는다** | `ui.js:59,97`. 높이 붕괴 → `scrollTop` 0 클램프 → 상점 스크롤이 매초 튄다 (`R-01b`) |
| R-4 | **사용자가 조작 중인 엘리먼트를 렌더가 파괴하지 않는다** | `ui.js:229`가 드래그 중 draggable을 `remove()` → 아이템을 놓친다 (`R-02`) |
| R-5 | **불변 계산은 렌더 밖으로** | `ui.js:100`이 매 tick `filter().sort()` 재실행 (`R-10`) |
| R-6 | **DOM 캐시는 null 검증** | `ui.js:18` `_cacheDom()`이 무검증. id 오타 1개로 게임 전체 정지 (`R-13`) |

**부분 렌더 계약** — 새 코드는 이 형태를 따른다:
```js
// gameState.js — 변경 이유를 함께 알린다
_notify(reason) { for (const fn of this._listeners) fn(this, reason); }
buyItem(id)  { /* ... */ this._notify('inventory'); }
tick()       { /* ... */ this._notify('tick'); }

// main.js — 이유별로 필요한 것만 그린다
state.subscribe((s, reason) => {
    if (reason === 'tick') return ui.renderTopBar();      // 숫자 2개만
    ui.renderAll();
});
```

---

## 3. 상태 규칙

| # | 규칙 | 왜 |
|---|---|---|
| S-1 | **모든 상태 변경은 `GameState` 메서드 안에서** | 직접 `state.points += n` 하면 `save()`/`_notify()`가 빠져 화면과 저장이 어긋난다 |
| S-2 | **`save()`를 tick에서 호출하지 않는다. 디바운스한다** | `localStorage`는 **동기 블로킹** API. 매초 4KB 쓰기는 저프로파일 기기에서 프레임을 떨어뜨린다 (`R-03`) |
| S-3 | **시간 경과는 `Date.now()` 델타로 계산한다. tick 횟수로 세지 않는다** | `setInterval`은 백그라운드 탭에서 최대 60초까지 throttle된다. 방치형 게임에서 방치가 손해가 된다 (`R-04`) |
| S-4 | **`load()`의 모든 필드는 타입·범위 검증 후 대입** | 이미 잘 되어 있다(`Number.isFinite`, `_clampLevelIdx`, `shopItemsById.has`). 새 필드도 반드시 같은 수준으로 |
| S-5 | **도달 불가 코드를 남기지 않는다** | `boostEndTime`을 세팅하는 코드가 없어 부스트 관련 4개 분기가 전부 죽어 있다 (`R-06`). 구현하거나 제거한다 — 남겨두면 다음 사람이 "동작하는 기능"으로 오해한다 |

---

## 4. DOM · 이벤트 규칙

| # | 규칙 | 근거 |
|---|---|---|
| D-1 | **리스너를 붙인 곳에는 cleanup을 반환한다** | `dragAndDrop.js`의 `makeDraggable` 반환 패턴이 정답. 새 입력 모듈도 동일하게 |
| D-2 | **포인터 이동/종료는 `window`에 바인딩** | 엘리먼트 바인딩은 `setPointerCapture` 실패 시 드래그가 유실된다 (`R-11`) |
| D-3 | **no-op 콜백을 넘기지 않는다. 인자를 옵셔널로** | `ui.js:245`가 빈 함수를 넘겨 매 `pointermove`마다 호출된다 (`R-12`) |
| D-4 | **모달 상태는 클래스로만 제어한다** | `style.css:265`에 `.modal-overlay.is-open`이 있는데 `ui.js:265`는 `style.display`를 직접 쓴다. 클래스는 죽고 인라인이 CSS 계약을 우회했다 (`R-07`) |
| D-5 | **`alert()`/`confirm()` 금지** | 커스텀 모달 시스템이 이미 있다. 네이티브 다이얼로그는 메인 스레드를 정지시키고 관료제 톤을 파괴한다 (`R-08`) |
| D-6 | **좌표 계산에 매직넘버를 쓰지 않는다** | `ui.js:277`의 `- 50`은 실제 아이템 크기(38px)와 불일치 (`R-09`). `el.offsetWidth`를 쓴다 |

---

## 5. 데이터 규칙

| # | 규칙 | 근거 |
|---|---|---|
| A-1 | **선언한 필드는 반드시 소비한다** | `item.set`(100건)·`item.category`(100건)이 읽히는 곳이 없다 (`D-03`,`D-06`). 사문 데이터는 잘못된 안전감을 준다 |
| A-2 | **그룹 정의와 보상 정의를 한 곳에서 파생시킨다** | 아이템은 9개 세트 그룹을 갖는데 `setEffects`는 5개뿐 → 37개 아이템이 보상 없는 유령 그룹 (`D-04`). 두 테이블을 손으로 맞추면 반드시 어긋난다 |
| A-3 | **매직넘버는 상수로** | `ITEM_BONUS_MULTIPLIER = 1.5` 패턴이 정답. 이 프로젝트가 이미 잘 하는 것 |
| A-4 | **색상 스케일은 단조성을 검증한다** | 등급 5색의 명도가 단조롭지 않아 일반(0.74)이 고급(0.73)보다 밝다 (`D-05`) |
| A-5 | **아이콘은 `WAIcons` 를 경유한다** | 이모지 직접 삽입 금지. `WAIcons.audit()`이 충돌·오배정을 자동 검출한다 |

---

## 6. 명명 · 서식

- 모듈 파일: `camelCase.js` (`gameState.js`, `dragAndDrop.js`) — 기존 규칙 유지
- 클래스: `PascalCase` · 메서드: `camelCase` · 내부 전용: `_` 접두 (`_cacheDom`, `_notify`)
- 상수: `SCREAMING_SNAKE` (`SAVE_KEY`, `TICK_MS`)
- 아이템 id: `item_N` (기존 형식 유지 — 세이브 호환)
- 글리프 id: `family-object-variant` kebab-case
- CSS 클래스: `kebab-case`, BEM 없음 (기존 규칙 유지)
- **일반명사 단독 클래스 금지.** `.floor` `.item` `.row` 같은 이름은 반드시 컨테이너 아래로 스코프한다
  (`.rank-journey .floor`). 실제 사고: V-7의 단면도 층 `.floor`가 V-8의 룸 바닥 라벨
  `.plane-hint.floor`와 충돌해 배경·그리드·패딩까지 물려받았다 — 콘솔 에러 없이 레이아웃만 깨진다
- 들여쓰기 4칸, 문장 끝 세미콜론, 문자열은 단일 인용부호 (기존 규칙 유지)
- **주석은 "왜"만 쓴다.** 이 코드베이스는 이미 잘한다:
  `"file://로 더블클릭해서 열어도 동작해야 하므로 ES 모듈 대신 IIFE"` — 이런 주석이 규칙을 지켜준다

---

## 7. 접근성 최소선 (신규 코드는 예외 없음)

- 상호작용 요소는 `<button>`. `<div onclick>` 금지
- `:focus-visible` 스타일 필수. 현재 규칙 0건 (`A-02`)
- 탭 UI는 `role="tablist"/"tab"/"tabpanel"` + `aria-selected` + `aria-controls` (`A-03`)
- 실시간 갱신 수치는 `aria-live="polite"` (`A-04`)
- 모달은 `role="dialog"` + `aria-modal` + 포커스 트랩 + ESC + 배경 클릭 닫기 (`A-05`)
- 아이콘은 의미가 있으면 `label`, 장식이면 `aria-hidden`. `WAIcons`가 자동 처리
- `user-select: none`은 **드래그 대상에만.** 문서 전체(`*`)에 걸지 않는다 (`A-01`)

---

## 8. 리뷰 체크리스트 (PR 통과 조건)

- [ ] `file://index.html` 더블클릭으로 열어 동작하는가
- [ ] 상점 탭을 스크롤한 뒤 3초간 두었을 때 스크롤이 유지되는가 *(R-01b 회귀 테스트)*
- [ ] 아이템을 3초 이상 잡고 드래그해도 놓치지 않는가 *(R-02 회귀 테스트)*
- [ ] 탭을 백그라운드로 1분 두고 돌아왔을 때 포인트가 정확한가 *(R-04 회귀 테스트)*
- [ ] `gameState.js`에 `document`가 없는가
- [ ] `ui.js`에서 state를 변경하지 않는가
- [ ] 새 필드를 선언했다면 실제로 읽는 코드가 있는가
- [ ] 세이브 스키마를 바꿨다면 `SAVE_VERSION`을 올리고 마이그레이션을 썼는가
- [ ] `alert`/`confirm`/이모지를 새로 넣지 않았는가
- [ ] `WAIcons.audit().pass === true`
- [ ] 키보드만으로 모든 기능에 도달할 수 있는가
- [ ] 새 색상이 `docs/DESIGN_DOCTRINE.md` §2 토큰 안에 있는가
- [ ] 레이아웃 정착 후 재보정이 필요한 배치를 `requestAnimationFrame`**만**으로 처리하지 않았는가
      — rAF는 비활성 탭·숨은 iframe에서 발동하지 않는다. `setTimeout` 폴백을 함께 건다 (`R-23`)
- [ ] `font-size`에 리터럴 px가 없는가 — 전부 `var(--fs-*)`를 경유하는가 (§3)
      ```js
      // 콘솔에서 즉시 검증
      [...document.styleSheets].flatMap(s => [...s.cssRules])
        .filter(r => r.style && /^\d/.test(r.style.fontSize)).map(r => r.selectorText)
      // → 빈 배열이어야 한다
      ```
- [ ] 렌더된 텍스트가 11px 미만인 곳이 없는가 — 스케일 하한 (§3)
- [ ] 텍스트 대비가 4.5:1 이상인가 — `Workspace.runTests()`의 `A-09` 항목 (§7)
      `--wa-ink-3`·`--wa-danger`를 텍스트에 쓰면 반드시 실패한다. 둘 다 괘선·채움 전용이다
- [ ] **새 검사를 추가했다면 일부러 회귀를 주입해 실패하는지 확인했는가**
      통과만 확인한 검사는 통과하지 않는다. `T-1c`·`T-1e`·`T-1f`가 전부 이 절차 부재로 생겼다
- [ ] **`opacity`로 상태를 표현하지 않았는가** — opacity는 자식 텍스트의 대비까지 함께 깎는다.
      후퇴는 지면(`--wa-ground-*`)이나 색이 맡는다 (실제 사고: `A-11`)

# P6 · 트리플A 업그레이드 로드맵

모든 항목은 `docs/ANALYSIS.md` 결함 ID를 역참조하거나 측정 가능한 목표 수치를 갖는다.

---

## 요약: 지금 무엇이 트리플A를 막는가

| 축 | 현재 | 병목 |
|---|---|---|
| **속도** | 초당 220 노드 재생성 + 초당 4KB 동기 저장 | `R-01` `R-03` |
| **기능** | 방치형인데 방치 수익 0. 승법 성장 레이어 0 | `R-05` `B-01` |
| **UX** | 상점 스크롤이 매초 초기화. 드래그가 1초 후 끊김 | `R-01b` `R-02` |

**세 축 모두 같은 뿌리에서 나온다: `tick == renderAll`.** 이걸 끊는 것이 1순위다.

---

## A. 속도 (SPEED)

### `S-1` 부분 렌더 — 최우선 [난이도 中 · 효과 특大]
> 해소: `R-01` `R-01b` `R-02` `R-10` — **치명 4건 중 3건이 이것 하나로 사라진다**

```js
// gameState.js — 변경 이유를 함께 알린다
_notify(reason) { for (const fn of this._listeners) fn(this, reason); }
buyItem(id)      { /* ... */ this._notify('inventory'); }
toggleEquip(id)  { /* ... */ this._notify('equipped'); }
buyPromotion()   { /* ... */ this._notify('level'); }
rebirth()        { /* ... */ this._notify('reset'); }
tick()           { /* ... */ this._notify('tick'); }

// main.js
state.subscribe((s, reason) => {
    switch (reason) {
        case 'tick':      ui.renderTopBar(); ui.renderBoostBar(); ui.refreshAffordability(); break;
        case 'inventory': ui.renderInventory(); ui.renderShop(); break;
        case 'equipped':  ui.renderInventory(); ui.renderSets(); ui.syncOffice(); break;
        default:          ui.renderAll();
    }
});
```
`refreshAffordability()`는 DOM을 재구축하지 않고 구매 버튼의 `disabled`만 토글한다:
```js
refreshAffordability() {
    for (const btn of this.dom.shopList.querySelectorAll('[data-action="buy-item"]')) {
        const item = shopItemsById.get(btn.dataset.id);
        if (!item) continue;
        const owned = this.state.inventory.has(item.id);
        btn.disabled = owned || this.state.points < item.cost;
    }
}
```
**측정 목표**: 초당 재생성 노드 220 → **0**. 상점 스크롤 유지, 드래그 무한 지속.

### `S-2` 오피스 룸 증분 동기화 [난이도 中 · 효과 大]
> 해소: `R-02`

`renderOffice()`를 전량 파괴에서 diff로 바꾼다. `equipped`의 id를 키로 기존 엘리먼트를 재사용하고, **드래그 중이면 그 엘리먼트는 건드리지 않는다.**
```js
syncOffice() {
    const want = new Set(this.state.equipped.map(e => e.id));
    for (const [id, rec] of this._placed) {
        if (!want.has(id)) { rec.cleanup(); rec.el.remove(); this._placed.delete(id); }
    }
    for (const eq of this.state.equipped) {
        if (this._placed.has(eq.id)) continue;   // 이미 있으면 손대지 않는다
        this._spawn(eq);
    }
    this.dom.officeEmptyMsg.style.display = this.state.equipped.length ? 'none' : 'block';
}
```

### `S-3` 저장 디바운스 [난이도 下 · 효과 大]
> 해소: `R-03`

```js
// gameState.js
_scheduleSave() {
    if (this._saveTimer) return;
    this._saveTimer = setTimeout(() => { this._saveTimer = null; this.save(); }, CONFIG.SAVE_DEBOUNCE_MS);
}
flushSave() { clearTimeout(this._saveTimer); this._saveTimer = null; this.save(); }
```
`tick()`은 `_scheduleSave()`, 구매·배치·승진·환생은 즉시 `save()`.
`pagehide` / `visibilitychange(hidden)` 에서 `flushSave()`.
**측정 목표**: 저장 횟수 60/분 → **12/분** (`SAVE_DEBOUNCE_MS = 5000`).

### `S-4` delta-time 루프 [난이도 下 · 효과 大]
> 해소: `R-04`

```js
tick(dtSec) {
    const { cps } = this.calculateStats();
    this.points += cps * dtSec;
    this._scheduleSave();
    this._notify('tick');
}
// main.js
let last = Date.now();
setInterval(() => {
    const now = Date.now();
    const dt = Math.min((now - last) / 1000, 60);   // 시계 점프 방어
    last = now;
    state.tick(dt);
}, CONFIG.TICK_MS);
```
**측정 목표**: 백그라운드 1분 후 포인트 오차 ±98% → **±1% 이내**.

### `S-5` 숫자 포맷 캐시 [난이도 下 · 효과 中]
`toLocaleString()`은 매초 호출된다. `Intl.NumberFormat` 인스턴스를 1회 생성해 재사용하고, 정수부가 바뀌지 않으면 DOM 쓰기를 건너뛴다.

---

## B. 기능 (FEATURE)

### `F-1` 오프라인 진행 ★ 방치형의 심장 [난이도 中 · 효과 특大]
> 해소: `R-05` — **현재 앱을 닫으면 수익이 0이다. 장르의 핵심 루프가 아예 없다.**

```js
// 세이브에 lastSeen 추가 (SAVE_VERSION 2 + 마이그레이션)
applyOfflineGain() {
    if (!this.lastSeen) return null;
    const rawSec = (Date.now() - this.lastSeen) / 1000;
    if (rawSec < 60) return null;
    const sec = Math.min(rawSec, CONFIG.OFFLINE_CAP_SEC);          // 8시간 상한
    const gain = this.calculateStats().cps * sec * CONFIG.OFFLINE_EFFICIENCY;  // 0.5
    this.points += gain;
    return { sec, gain, capped: rawSec > CONFIG.OFFLINE_CAP_SEC };
}
```
복귀 시 **결재 서식 모달**로 보고한다 (교리 축 5):
`[근무 외 시간 정산서] 경과 3시간 12분 · 자동 집계 +48,210 P · 효율 50% 적용`

### `F-2` 성장 곡선 재설계 ★ [난이도 中 · 효과 특大]
> 해소: `B-01` — **현재 최고가 아이템은 이론상 최대 출력으로도 42.6일이 걸린다.**

비용은 지수(600,000배)인데 생산성은 가법 선형이다. 승법 레이어를 넣는다:

| 레이어 | 현재 | 개선 |
|---|---|---|
| 아이템 보너스 | 가법 `+bonus%` | 유지 (기반 소득) |
| 세트 보너스 | 가법 `+extraBonus%` | **배율 `×1.15`** 로 전환 |
| 직급 | 가법 `+bonusReward%` | **직급별 전역 배율 `×1.6^levelIdx`** |
| 환생 | 가법 `+rebirthReward%` | **누적 배율 `×(1 + Σreward/100)`** |

```js
cps = 1.0 * (1 + itemBonusSum/100) * setMult * rankMult * rebirthMult * boostMult;
```
**측정 목표**: 최종 아이템 도달 시간 42.6일 → **6~10시간**. 각 직급 구간 체류 15~40분.
> ⚠ 세이브 호환은 유지된다(저장 필드 불변, 계산식만 변경). 다만 밸런스 대수술이므로 **별도 승인 필요**.

### `F-3` 사직서 부스트 완성 [난이도 下 · 효과 中]
> 해소: `R-06` — 현재 기능을 광고하고 거부한다.

개그를 살리면서 기능도 살리는 안: **첫 제출은 반려(현재 모달 그대로), 두 번째부터 실제 발동.**
```js
activateBoost() {
    const now = Date.now();
    if (now < this.boostCooldownTime) return { state: 'cooldown', until: this.boostCooldownTime };
    if (!this.resignationRejectedOnce) { this.resignationRejectedOnce = true; this.save(); return { state: 'rejected' }; }
    this.boostEndTime = now + CONFIG.BOOST_DURATION_MS;      // 10분
    this.boostCooldownTime = this.boostEndTime + CONFIG.BOOST_COOLDOWN_MS;  // +30분
    this.save(); this._notify('boost');
    return { state: 'active', until: this.boostEndTime };
}
```
사직서 바는 3상태(대기 / 작동 중 · 남은시간 / 쿨다운 · 남은시간)를 정확히 반영한다.

### `F-4` 유령 세트 구제 [난이도 下 · 효과 大]
> 해소: `D-04` — 37개 아이템(37%)이 보상 없는 그룹에 속해 있다.

`plant` `lounge` `meeting` `endgame` 4종을 `setEffects`에 추가. 레벨 4~10 콘텐츠 전체가 세트 시스템에 편입된다.

### `F-5` `set` 필드를 실제 시스템으로 [난이도 中 · 효과 大]
> 해소: `D-03` — `item.set` 100건이 사문이다.

`setEffects`의 하드코딩 `items` 배열 대신 **`set` 그룹에서 N개 배치 시 단계 보너스**:
```js
// 그룹 내 배치 수에 따라 3/5/8개 = 3단계 보너스
const tiers = [{ n: 3, mult: 1.05 }, { n: 5, mult: 1.10 }, { n: 8, mult: 1.20 }];
```
효과: (a) 사문 데이터가 시스템이 된다 (b) 두 테이블을 손으로 맞추는 `D-04` 유형 버그가 구조적으로 불가능해진다 (c) 수집 동기가 "특정 3개"에서 "그룹 채우기"로 확장된다.

### `F-6` `category` 필터 [난이도 下 · 효과 中]
> 해소: `D-06` — `category` 14종이 사문이다. 상점 15종 목록이 평면 리스트라 탐색이 어렵다.

카테고리 칩 필터를 상점 상단에 추가. 데이터는 이미 다 있다.

### `F-7` 배치 그리드 스냅 + 충돌 회피 [난이도 下 · 효과 中]
> 해소: `R-09`

24px 그리드 스냅 — **청사진 교리(격자 규율)와 정확히 일치한다.** 스폰 시 빈 셀을 탐색해 겹침을 방지하고, `- 50` 매직넘버를 `el.offsetWidth`로 대체.

---

## C. 사용자 경험 (UX)

### `U-1` 아이콘 · 등급 색 통합 [난이도 下 · 효과 특大] — **P3에서 이미 제작 완료**
> 해소: `D-01`(60건 충돌) `D-02`(8건 오배정) `D-05`(등급 명도 역전) `A-07`(스크린리더)

`icons/ICON_SPEC.md` §6의 통합 절차만 남았다. 4곳 교체.

### `U-2` 네이티브 다이얼로그 제거 [난이도 下 · 효과 大]
> 해소: `R-08` `R-07`

`alert`/`confirm` 4곳 → 결재 서식 모달. 동시에 모달 제어를 `.is-open` 클래스로 통일해 죽은 셀렉터를 살린다.

### `U-3` 접근성 [난이도 中 · 효과 大]
> 해소: `A-01`~`A-08` (8건)

1. `* { user-select: none }` 제거 → `.draggable-item`에만
2. `:focus-visible { outline: 2px solid var(--wa-gilt); outline-offset: 2px }`
3. 탭 UI에 `role="tablist"/"tab"/"tabpanel"` + `aria-selected` + `aria-controls` + 좌우 화살표 키
4. 포인트/CPS에 `aria-live="polite"`
5. 모달에 `role="dialog"` + `aria-modal` + 포커스 트랩 + ESC + 배경 클릭
6. `body { overflow: hidden }` → `overflow-y: auto`

### `U-4` 수치 표기 안정화 [난이도 下 · 효과 中]
`IBM Plex Mono` + `font-variant-numeric: tabular-nums`. 1e6 이상은 `1.24M` 축약. 자릿수 변화 시 헤더가 흔들리는 문제가 사라진다.

### `U-5` 피드백 복원 [난이도 下 · 효과 中 — S-1 선행 필수]
현재는 구매해도 아무 피드백이 없다. 카드가 매초 재생성되므로 애니메이션이 물리적으로 불가능하다. `S-1` 이후:
- 구매 시 카드에 결재 도장(`sys-stamp`) 스탬프 인
- 포인트 증가 시 `+N` 티커
- 세트 완성 시 세트 박스 금박 플래시

### `U-6` 진행 게이지 [난이도 下 · 효과 中]
다음 승진까지의 진행률 바. 현재는 숫자 비교뿐이라 "얼마나 남았는지"의 체감이 없다.

---

## D. 우선순위 스프린트

### `Sprint 1` 기반 — 치명 결함 전멸 (1일)
`S-1` → `S-2` → `S-3` → `S-4`
**완료 판정**: 상점 스크롤 유지 · 드래그 무한 지속 · 백그라운드 1분 오차 ±1% · 초당 재생성 노드 0

### `Sprint 2` 정체성 (1일)
`U-1` → `U-2` → `U-4`
**완료 판정**: 이모지 0건 · `WAIcons.audit().pass` · `alert`/`confirm` 0건 · 100개 아이템 전부 식별 가능

### `Sprint 3` 방치형 루프 (2일)
`F-1` → `F-3` → `F-2`(승인 후)
**완료 판정**: 오프라인 복귀 정산 동작 · 부스트 3상태 정확 · 최종 아이템 도달 6~10시간

### `Sprint 5` 공간 — 완료
`V-1` 도면 룸(2평면 + 기준선 + 등록 마크) → `V-2` 배치 레이어(wall/desk/floor · category 소비 · 깊이 정렬) → `V-3` 선택 + 인스펙터 → `V-4` 표제부
**완료 판정**: 룸이 정면도로 읽힌다 · 사물이 있어야 할 평면에 놓인다 · 방이 자기 자신을 설명한다

### `Sprint 4` 깊이 (2~3일)
`F-4` → `F-5` → `F-6` → `F-7` → `U-3` → `U-5` → `U-6`
**완료 판정**: 사문 데이터 0건 · 접근성 8건 해소 · 키보드 단독 플레이 가능

---

## E. 난이도 × 효과 매트릭스

```
효과 특大 │ S-1  F-1  F-2  U-1
효과 大   │ S-2  S-3  S-4  F-4  F-5  U-2  U-3
효과 中   │ S-5  F-3  F-6  F-7  U-4  U-5  U-6
          └─────────────────────────────────────
            난이도 下 ────────────────► 中
```

**즉시 착수 권장 (난이도 下 + 효과 大 이상)**: `S-3` `S-4` `U-1` `U-2` `F-4`
이 5개만으로 치명 결함 2건 + 높음 결함 5건이 해소되고 아이콘 정체성이 확립된다.

---

## F. 승인이 필요한 항목

| 항목 | 이유 |
|---|---|
| `F-2` 성장 곡선 재설계 | 밸런스 대수술. 기존 플레이어의 체감이 크게 바뀐다 |
| `F-5` set 시스템 전환 | `setEffects` 의미가 바뀐다. 기존 5세트 보상이 재해석된다 |
| `F-3` 부스트 "첫 제출 반려" | 개그를 기능에 편입시키는 서사 결정 |
| 신규 콘텐츠 (업적 · 일일 목표 · 동료 NPC) | **제안하지 않고 묻는다.** 대상 사용자와 목표는 기획자가 안다 |

> `F-2`·`F-5`는 포인트 단위·승진 소요 시간 논의가 진행 중이므로 보류 상태다(2026-08). 결정 전까지 착수하지 않는다.

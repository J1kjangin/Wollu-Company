// js/gameState.js
// 상태 + 게임 규칙만 담당. DOM 접근 없음(테스트 용이, UI 교체에 안전).
window.Workspace = window.Workspace || {};

(function (ns) {
    const { levels, shopItemsById, setEffects, CONFIG } = ns.data;

    class GameState {
        constructor() {
            this.points = 0;
            this.levelIdx = 0;
            this.inventory = new Set();
            this.equipped = []; // [{ id, x, y }]
            this.rebirthCount = 0;
            this.totalRebirthBonus = 0;
            // 사직서 부스트: 필드는 존재하지만 이를 실제로 세팅하는 UI(부스트 발동)가
            // 아직 없다(현재는 "반려" 모달만 뜸). 향후 기능이 완성되면
            // activateBoost() 같은 메서드를 여기에 추가하면 된다.
            this.boostEndTime = 0;
            this.boostCooldownTime = 0;
            this._listeners = new Set();
        }

        subscribe(fn) {
            this._listeners.add(fn);
            return () => this._listeners.delete(fn);
        }
        _notify() {
            for (const fn of this._listeners) fn(this);
        }

        load() {
            let raw;
            try {
                raw = localStorage.getItem(CONFIG.SAVE_KEY);
            } catch (err) {
                console.error('[GameState] localStorage 접근 실패:', err);
                return;
            }
            if (!raw) return;

            try {
                const parsed = JSON.parse(raw);
                this.points = Number.isFinite(parsed.points) && parsed.points >= 0 ? parsed.points : 0;
                this.levelIdx = Number.isInteger(parsed.levelIdx) ? this._clampLevelIdx(parsed.levelIdx) : 0;
                this.inventory = new Set(Array.isArray(parsed.inventory) ? parsed.inventory.filter(id => shopItemsById.has(id)) : []);
                this.rebirthCount = Number.isInteger(parsed.rebirthCount) ? Math.max(0, Math.min(parsed.rebirthCount, CONFIG.MAX_REBIRTH)) : 0;
                this.totalRebirthBonus = Number.isFinite(parsed.totalRebirthBonus) ? parsed.totalRebirthBonus : 0;
                this.boostEndTime = Number.isFinite(parsed.boostEndTime) ? parsed.boostEndTime : 0;
                this.boostCooldownTime = Number.isFinite(parsed.boostCooldownTime) ? parsed.boostCooldownTime : 0;
                this.equipped = Array.isArray(parsed.equipped)
                    ? parsed.equipped.filter(e => e && typeof e.id === 'string' && shopItemsById.has(e.id) && this.inventory.has(e.id))
                    : [];
            } catch (err) {
                console.error('[GameState] 세이브 파싱 실패, 초기 상태로 진행:', err);
            }
        }

        save() {
            try {
                const payload = {
                    version: CONFIG.SAVE_VERSION,
                    points: this.points,
                    levelIdx: this.levelIdx,
                    inventory: Array.from(this.inventory),
                    equipped: this.equipped,
                    rebirthCount: this.rebirthCount,
                    totalRebirthBonus: this.totalRebirthBonus,
                    boostEndTime: this.boostEndTime,
                    boostCooldownTime: this.boostCooldownTime,
                };
                localStorage.setItem(CONFIG.SAVE_KEY, JSON.stringify(payload));
            } catch (err) {
                console.error('[GameState] 저장 실패(저장공간 부족 등):', err);
            }
        }

        _clampLevelIdx(idx) {
            return Math.max(0, Math.min(idx, levels.length - 1));
        }

        getCurrentLevel() { return levels[this.levelIdx]; }
        getNextLevel() { return levels[this.levelIdx + 1] || null; }

        calculateStats() {
            let itemBonusSum = 0;
            for (const eq of this.equipped) {
                const item = shopItemsById.get(eq.id);
                if (item) itemBonusSum += item.bonus;
            }

            const equippedIds = new Set(this.equipped.map(e => e.id));
            let setBonusSum = 0;
            for (const set of setEffects) {
                if (set.items.every(id => equippedIds.has(id))) setBonusSum += set.extraBonus;
            }

            const rankBonus = this.getCurrentLevel().bonusReward;
            const totalBonusPct = itemBonusSum + setBonusSum + rankBonus + this.totalRebirthBonus;
            let cps = 1.0 * (1 + totalBonusPct / 100);

            const boostActive = Date.now() < this.boostEndTime;
            if (boostActive) cps *= CONFIG.BOOST_MULTIPLIER;

            return { cps, totalBonusPct, rankBonus, boostActive };
        }

        buyItem(id) {
            const item = shopItemsById.get(id);
            if (!item || this.inventory.has(id) || this.points < item.cost) return false;
            this.points -= item.cost;
            this.inventory.add(id);
            this.save();
            this._notify();
            return true;
        }

        toggleEquip(id, spawnPos = { x: 10, y: 10 }) {
            if (!this.inventory.has(id)) return false;
            const idx = this.equipped.findIndex(e => e.id === id);
            if (idx > -1) {
                this.equipped.splice(idx, 1);
            } else {
                this.equipped.push({ id, x: spawnPos.x, y: spawnPos.y });
            }
            this.save();
            this._notify();
            return true;
        }

        updateEquippedPosition(id, x, y) {
            const eq = this.equipped.find(e => e.id === id);
            if (!eq) return;
            eq.x = x;
            eq.y = y;
            this.save();
        }

        buyPromotion() {
            const next = this.getNextLevel();
            if (!next || this.points < next.cost) return null;
            this.points -= next.cost;
            this.levelIdx++;
            this.save();
            this._notify();
            return next;
        }

        canRebirth() {
            return this.levelIdx > 0 && this.rebirthCount < CONFIG.MAX_REBIRTH;
        }

        rebirth() {
            if (!this.canRebirth()) return null;
            const current = this.getCurrentLevel();
            const reward = current.rebirthReward;

            this.rebirthCount++;
            this.totalRebirthBonus += reward;
            this.points = 0;
            this.levelIdx = 0;
            this.inventory.clear();
            this.equipped = [];

            this.save();
            this._notify();
            return { levelName: current.name, reward, rebirthCount: this.rebirthCount };
        }

        tick() {
            const { cps } = this.calculateStats();
            this.points += cps;
            this.save();
            this._notify();
        }
    }

    ns.GameState = GameState;
})(window.Workspace);

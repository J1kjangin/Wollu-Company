// js/main.js
// 앱 조립(composition root). 여기서만 GameState/UI를 생성하고 서로 연결한다.
// 모든 클릭은 data-action 이벤트 위임으로 처리 → 전역 함수 오염 없음.
window.Workspace = window.Workspace || {};

(function (ns) {
    const { CONFIG } = ns.data;
    const { GameState, UI } = ns;

    function bootstrap() {
        const state = new GameState();
        state.load();

        const ui = new UI(state);

        // 디버깅/테스트 편의를 위해 상태 인스턴스를 네임스페이스에 노출.
        // (프로덕션 로직에서는 이걸 참조하지 않는다 — 오직 devtools 콘솔/테스트 스크립트용)
        ns.state = state;

        state.subscribe(() => ui.renderAll());
        ui.renderAll();
        ui.openModal('intro-modal'); // 부팅 시 안내 모달 표시

        document.body.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            const action = target.dataset.action;
            const id = target.dataset.id;

            switch (action) {
                case 'buy-item':
                    state.buyItem(id);
                    break;
                case 'toggle-equip':
                    state.toggleEquip(id, ui.getRandomSpawnPos());
                    break;
                case 'buy-promotion':
                    handlePromotion();
                    break;
                case 'switch-tab':
                    ui.switchTab(target.dataset.tab);
                    break;
                case 'rebirth':
                    handleRebirth();
                    break;
                case 'resignation-boost':
                    // 부스트 기능은 아직 미구현 → 안내 모달만 띄운다 (data.js CONFIG 주석 참고)
                    ui.openModal('resignation-modal');
                    break;
                case 'close-modal':
                    ui.closeModal(target.dataset.modal);
                    break;
                default:
                    console.warn('[main] 알 수 없는 action:', action);
            }
        });

        document.querySelectorAll('.tab-btn[data-tab]').forEach(btn => {
            btn.addEventListener('click', () => ui.switchTab(btn.dataset.tab));
        });

        function handlePromotion() {
            const promoted = state.buyPromotion();
            if (promoted) {
                alert(`축하합니다! [${promoted.name}]으로 승진하여 생산성 보너스가 +${promoted.bonusReward}% 적용됩니다!`);
            }
        }

        function handleRebirth() {
            if (state.levelIdx === 0) {
                alert("인턴 기간에는 환생할 수 없습니다! 최소 '사원' 이상으로 승진한 뒤 환생을 진행해 주세요.");
                return;
            }
            if (!state.canRebirth()) {
                alert(`최대 환생 횟수(${CONFIG.MAX_REBIRTH}회)에 도달하여 더 이상 환생할 수 없습니다!`);
                return;
            }
            const current = state.getCurrentLevel();
            const confirmed = confirm(
                `현재 직급 [${current.name}]으로 환생을 진행하시겠습니까?\n영구 보너스가 +${current.rebirthReward}% 증가하며 자산 포인트가 초기화됩니다!`
            );
            if (!confirmed) return;

            const result = state.rebirth();
            if (result) {
                alert(`환생 완료! 영구 보너스 +${result.reward}%가 누적되었습니다. (총 환생: ${result.rebirthCount}/${CONFIG.MAX_REBIRTH}회)`);
            }
        }

        // 부스트 상태(카운트다운 등)는 게임 루프에서 자동으로 갱신됨
        setInterval(() => state.tick(), CONFIG.TICK_MS);
    }

    document.addEventListener('DOMContentLoaded', bootstrap);
})(window.Workspace);

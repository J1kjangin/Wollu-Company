// js/dragAndDrop.js
// 드래그 로직을 UI 렌더링 코드에서 분리. 다른 화면에서도 재사용 가능.
window.Workspace = window.Workspace || {};

(function (ns) {
    /**
     * @returns {() => void} cleanup 함수 (메모리 누수 방지를 위해 재렌더 시 호출)
     */
    function makeDraggable(el, containerEl, initialPos, onMove, onDragEnd) {
        let dragging = false;
        let startX = 0;
        let startY = 0;
        let pos = { ...initialPos };

        el.style.left = pos.x + 'px';
        el.style.top = pos.y + 'px';

        const onPointerDown = (e) => {
            dragging = true;
            el.setPointerCapture(e.pointerId);
            startX = e.clientX - pos.x;
            startY = e.clientY - pos.y;
            e.stopPropagation();
        };

        const onPointerMove = (e) => {
            if (!dragging) return;
            const maxX = Math.max(0, containerEl.clientWidth - el.offsetWidth);
            const maxY = Math.max(0, containerEl.clientHeight - el.offsetHeight);

            let newX = e.clientX - startX;
            let newY = e.clientY - startY;
            newX = Math.max(0, Math.min(newX, maxX));
            newY = Math.max(0, Math.min(newY, maxY));

            pos = { x: newX, y: newY };
            el.style.left = newX + 'px';
            el.style.top = newY + 'px';
            onMove(newX, newY);
        };

        const onPointerUp = (e) => {
            if (!dragging) return;
            dragging = false;
            try { el.releasePointerCapture(e.pointerId); } catch (_) { /* 이미 해제된 경우 무시 */ }
            onDragEnd(pos.x, pos.y);
        };

        el.addEventListener('pointerdown', onPointerDown);
        el.addEventListener('pointermove', onPointerMove);
        el.addEventListener('pointerup', onPointerUp);
        el.addEventListener('pointercancel', onPointerUp);

        return () => {
            el.removeEventListener('pointerdown', onPointerDown);
            el.removeEventListener('pointermove', onPointerMove);
            el.removeEventListener('pointerup', onPointerUp);
            el.removeEventListener('pointercancel', onPointerUp);
        };
    }

    ns.dragAndDrop = { makeDraggable };
})(window.Workspace);

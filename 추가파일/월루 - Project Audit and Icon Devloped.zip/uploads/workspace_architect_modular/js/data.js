// js/data.js
// 게임 밸런스/콘텐츠 데이터 전용 모듈. 로직/렌더링 코드를 포함하지 않는다.
// file://로 더블클릭해서 열어도 동작해야 하므로 ES 모듈(import/export) 대신
// IIFE + 전역 네임스페이스(window.Workspace.*) 방식을 쓴다.
window.Workspace = window.Workspace || {};

(function (ns) {
    const CONFIG = Object.freeze({
        SAVE_KEY: 'workspaceArchitectSave',
        SAVE_VERSION: 1,
        TICK_MS: 1000,
        MAX_REBIRTH: 10,
        BOOST_MULTIPLIER: 2,
        // 부스트 기능은 아직 미구현 상태(사직서 반려 모달만 존재).
        // 실제로 발동시키는 UI가 붙기 전까지는 boostEndTime이 항상 0이라 배율은 걸리지 않는다.
    });

    // 원본(raw) 밸런스 데이터. 여기에 새 아이템을 추가하면 됨.
    const rawShopItems = Object.freeze([
        { id: "item_1", name: "기본 책상", icon: "🪵", cost: 250, bonus: 2, rarity: "normal", category: "책상", set: "desk", requiredLevel: 0 },
        { id: "item_2", name: "원목 책상", icon: "🪵", cost: 500, bonus: 4, rarity: "advanced", category: "책상", set: "desk", requiredLevel: 0 },
        { id: "item_3", name: "화이트 책상", icon: "🪑", cost: 750, bonus: 4, rarity: "advanced", category: "책상", set: "desk", requiredLevel: 0 },
        { id: "item_4", name: "기본 사무용 의자", icon: "🪑", cost: 250, bonus: 2, rarity: "normal", category: "의자", set: "desk", requiredLevel: 0 },
        { id: "item_5", name: "푹신한 의자", icon: "🛋️", cost: 600, bonus: 4, rarity: "advanced", category: "의자", set: "desk", requiredLevel: 0 },
        { id: "item_6", name: "회전 의자", icon: "💺", cost: 1000, bonus: 6, rarity: "advanced", category: "의자", set: "desk", requiredLevel: 0 },
        { id: "item_7", name: "노트", icon: "📓", cost: 50, bonus: 1, rarity: "normal", category: "문구", set: "desk", requiredLevel: 0 },
        { id: "item_8", name: "업무 노트", icon: "📓", cost: 150, bonus: 2, rarity: "normal", category: "문구", set: "desk", requiredLevel: 0 },
        { id: "item_9", name: "다이어리", icon: "📖", cost: 400, bonus: 4, rarity: "normal", category: "문구", set: "desk", requiredLevel: 0 },
        { id: "item_10", name: "연필 세트", icon: "✏️", cost: 50, bonus: 1, rarity: "normal", category: "문구", set: "desk", requiredLevel: 0 },
        { id: "item_11", name: "볼펜 세트", icon: "🖊️", cost: 150, bonus: 2, rarity: "normal", category: "문구", set: "desk", requiredLevel: 0 },
        { id: "item_12", name: "형광펜 세트", icon: "🖍️", cost: 250, bonus: 3, rarity: "normal", category: "문구", set: "desk", requiredLevel: 0 },
        { id: "item_13", name: "책상 달력", icon: "📅", cost: 350, bonus: 2, rarity: "normal", category: "장식", set: "desk", requiredLevel: 0 },
        { id: "item_14", name: "서류철", icon: "📁", cost: 500, bonus: 3, rarity: "advanced", category: "수납", set: "desk", requiredLevel: 0 },
        { id: "item_15", name: "메모지", icon: "📝", cost: 100, bonus: 1, rarity: "normal", category: "문구", set: "desk", requiredLevel: 0 },

        { id: "item_16", name: "기본 모니터", icon: "🖥️", cost: 1500, bonus: 6, rarity: "advanced", category: "컴퓨터", set: "pc", requiredLevel: 1 },
        { id: "item_17", name: "와이드 모니터", icon: "🖥️", cost: 3000, bonus: 10, rarity: "rare", category: "컴퓨터", set: "pc", requiredLevel: 1 },
        { id: "item_18", name: "듀얼 모니터", icon: "🖥️", cost: 6000, bonus: 16, rarity: "rare", category: "컴퓨터", set: "pc", requiredLevel: 1 },
        { id: "item_19", name: "울트라와이드 모니터", icon: "🖥️", cost: 12500, bonus: 24, rarity: "rare", category: "컴퓨터", set: "pc", requiredLevel: 1 },
        { id: "item_20", name: "기본 키보드", icon: "⌨️", cost: 1000, bonus: 4, rarity: "normal", category: "컴퓨터", set: "pc", requiredLevel: 1 },
        { id: "item_21", name: "기계식 키보드", icon: "⌨️", cost: 2500, bonus: 8, rarity: "advanced", category: "컴퓨터", set: "pc", requiredLevel: 1 },
        { id: "item_22", name: "저소음 키보드", icon: "⌨️", cost: 4000, bonus: 10, rarity: "advanced", category: "컴퓨터", set: "pc", requiredLevel: 1 },
        { id: "item_23", name: "무선 키보드", icon: "⌨️", cost: 5000, bonus: 12, rarity: "advanced", category: "컴퓨터", set: "pc", requiredLevel: 1 },
        { id: "item_24", name: "기본 마우스", icon: "🖱️", cost: 750, bonus: 4, rarity: "normal", category: "컴퓨터", set: "pc", requiredLevel: 1 },
        { id: "item_25", name: "무선 마우스", icon: "🖱️", cost: 2000, bonus: 8, rarity: "advanced", category: "컴퓨터", set: "pc", requiredLevel: 1 },
        { id: "item_26", name: "인체공학 마우스", icon: "🖱️", cost: 3500, bonus: 10, rarity: "advanced", category: "컴퓨터", set: "pc", requiredLevel: 1 },
        { id: "item_27", name: "고급 마우스", icon: "🖱️", cost: 6000, bonus: 14, rarity: "rare", category: "컴퓨터", set: "pc", requiredLevel: 1 },
        { id: "item_28", name: "마우스패드", icon: "🔲", cost: 500, bonus: 2, rarity: "normal", category: "컴퓨터", set: "pc", requiredLevel: 1 },
        { id: "item_29", name: "대형 마우스패드", icon: "⬛", cost: 1500, bonus: 6, rarity: "advanced", category: "컴퓨터", set: "pc", requiredLevel: 1 },
        { id: "item_30", name: "헤드셋", icon: "🎧", cost: 3000, bonus: 8, rarity: "advanced", category: "컴퓨터", set: "pc", requiredLevel: 1 },

        { id: "item_31", name: "기본 텀블러", icon: "🥤", cost: 2500, bonus: 6, rarity: "advanced", category: "생활용품", set: "caffeine", requiredLevel: 2 },
        { id: "item_32", name: "스테인리스 텀블러", icon: "🥤", cost: 5000, bonus: 10, rarity: "advanced", category: "생활용품", set: "caffeine", requiredLevel: 2 },
        { id: "item_33", name: "고급 텀블러", icon: "🥤", cost: 10000, bonus: 14, rarity: "rare", category: "생활용품", set: "caffeine", requiredLevel: 2 },
        { id: "item_34", name: "머그컵", icon: "☕", cost: 1500, bonus: 4, rarity: "normal", category: "생활용품", set: "caffeine", requiredLevel: 2 },
        { id: "item_35", name: "회사 로고 머그컵", icon: "☕", cost: 3500, bonus: 8, rarity: "advanced", category: "생활용품", set: "caffeine", requiredLevel: 2 },
        { id: "item_36", name: "커피잔 세트", icon: "☕", cost: 7500, bonus: 12, rarity: "rare", category: "생활용품", set: "caffeine", requiredLevel: 2 },
        { id: "item_37", name: "작은 화분", icon: "🪴", cost: 2000, bonus: 4, rarity: "advanced", category: "식물/장식", set: "plant", requiredLevel: 2 },
        { id: "item_38", name: "선인장", icon: "🌵", cost: 3000, bonus: 6, rarity: "advanced", category: "식물/장식", set: "plant", requiredLevel: 2 },
        { id: "item_39", name: "대형 화분", icon: "🌿", cost: 7500, bonus: 12, rarity: "rare", category: "식물/장식", set: "plant", requiredLevel: 2 },
        { id: "item_40", name: "책상 스탠드", icon: "💡", cost: 2500, bonus: 6, rarity: "advanced", category: "조명", set: "plant", requiredLevel: 2 },
        { id: "item_41", name: "고급 스탠드", icon: "🛋️", cost: 6000, bonus: 10, rarity: "rare", category: "조명", set: "plant", requiredLevel: 2 },
        { id: "item_42", name: "디지털 시계", icon: "⏰", cost: 4000, bonus: 8, rarity: "advanced", category: "장식", set: "plant", requiredLevel: 2 },
        { id: "item_43", name: "벽시계", icon: "🕒", cost: 3000, bonus: 6, rarity: "advanced", category: "장식", set: "plant", requiredLevel: 2 },
        { id: "item_44", name: "향초", icon: "🕯️", cost: 5000, bonus: 8, rarity: "advanced", category: "장식", set: "plant", requiredLevel: 2 },
        { id: "item_45", name: "간식통", icon: "🍪", cost: 2500, bonus: 6, rarity: "normal", category: "생활용품", set: "caffeine", requiredLevel: 2 },

        { id: "item_46", name: "서류함", icon: "🗄️", cost: 7500, bonus: 8, rarity: "advanced", category: "수납", set: "pro", requiredLevel: 3 },
        { id: "item_47", name: "3단 서류함", icon: "🗄️", cost: 12500, bonus: 12, rarity: "rare", category: "수납", set: "pro", requiredLevel: 3 },
        { id: "item_48", name: "캐비닛", icon: "🗃️", cost: 15000, bonus: 14, rarity: "rare", category: "수납", set: "pro", requiredLevel: 3 },
        { id: "item_49", name: "고급 캐비닛", icon: "🗃️", cost: 25000, bonus: 20, rarity: "rare", category: "수납", set: "pro", requiredLevel: 3 },
        { id: "item_50", name: "책장", icon: "📚", cost: 17500, bonus: 14, rarity: "rare", category: "수납", set: "pro", requiredLevel: 3 },
        { id: "item_51", name: "대형 책장", icon: "📚", cost: 30000, bonus: 20, rarity: "rare", category: "수납", set: "pro", requiredLevel: 3 },
        { id: "item_52", name: "프린터", icon: "🖨️", cost: 12500, bonus: 12, rarity: "rare", category: "사무기기", set: "pro", requiredLevel: 3 },
        { id: "item_53", name: "컬러 프린터", icon: "🖨️", cost: 25000, bonus: 18, rarity: "rare", category: "사무기기", set: "pro", requiredLevel: 3 },
        { id: "item_54", name: "복합기", icon: "🖨️", cost: 40000, bonus: 24, rarity: "legendary", category: "사무기기", set: "pro", requiredLevel: 3 },
        { id: "item_55", name: "유선 전화기", icon: "☎️", cost: 7500, bonus: 8, rarity: "advanced", category: "사무기기", set: "pro", requiredLevel: 3 },
        { id: "item_56", name: "사무용 전화기", icon: "☎️", cost: 15000, bonus: 12, rarity: "advanced", category: "사무기기", set: "pro", requiredLevel: 3 },
        { id: "item_57", name: "명패", icon: "📛", cost: 5000, bonus: 6, rarity: "normal", category: "장식", set: "pro", requiredLevel: 3 },
        { id: "item_58", name: "사원증 거치대", icon: "🪪", cost: 4000, bonus: 4, rarity: "normal", category: "사무용품", set: "pro", requiredLevel: 3 },
        { id: "item_59", name: "코르크 게시판", icon: "📌", cost: 6000, bonus: 8, rarity: "advanced", category: "장식", set: "pro", requiredLevel: 3 },
        { id: "item_60", name: "화이트보드", icon: "📋", cost: 10000, bonus: 10, rarity: "advanced", category: "사무기기", set: "pro", requiredLevel: 3 },

        { id: "item_61", name: "1인 소파", icon: "🛋️", cost: 50000, bonus: 16, rarity: "rare", category: "휴게공간", set: "lounge", requiredLevel: 4 },
        { id: "item_62", name: "2인 소파", icon: "🛋️", cost: 90000, bonus: 24, rarity: "rare", category: "휴게공간", set: "lounge", requiredLevel: 4 },
        { id: "item_63", name: "3인 소파", icon: "🛋️", cost: 150000, bonus: 30, rarity: "legendary", category: "휴게공간", set: "lounge", requiredLevel: 4 },
        { id: "item_64", name: "회의 테이블", icon: "🪑", cost: 125000, bonus: 24, rarity: "rare", category: "회의실", set: "lounge", requiredLevel: 4 },
        { id: "item_65", name: "커피 테이블", icon: "☕", cost: 75000, bonus: 16, rarity: "rare", category: "휴게공간", set: "lounge", requiredLevel: 4 },
        { id: "item_66", name: "대형 TV", icon: "📺", cost: 150000, bonus: 30, rarity: "legendary", category: "휴게공간", set: "lounge", requiredLevel: 4 },
        { id: "item_67", name: "공기청정기", icon: "🌬️", cost: 60000, bonus: 14, rarity: "rare", category: "생활용품", set: "lounge", requiredLevel: 4 },
        { id: "item_68", name: "냉장고", icon: "🧊", cost: 100000, bonus: 20, rarity: "rare", category: "생활용품", set: "lounge", requiredLevel: 4 },
        { id: "item_69", name: "전자레인지", icon: "🔥", cost: 50000, bonus: 12, rarity: "rare", category: "생활용품", set: "lounge", requiredLevel: 4 },
        { id: "item_70", name: "커피머신", icon: "☕", cost: 125000, bonus: 30, rarity: "legendary", category: "생활용품", set: "caffeine", requiredLevel: 4 },

        { id: "item_71", name: "CEO 스타일 책상", icon: "🪑", cost: 250000, bonus: 30, rarity: "legendary", category: "책상", set: "boss", requiredLevel: 5 },
        { id: "item_72", name: "대형 CEO 의자", icon: "💺", cost: 200000, bonus: 24, rarity: "legendary", category: "의자", set: "boss", requiredLevel: 5 },
        { id: "item_73", name: "차장실 대형 책장", icon: "📚", cost: 175000, bonus: 20, rarity: "legendary", category: "수납", set: "boss", requiredLevel: 5 },
        { id: "item_74", name: "고급 조명", icon: "💡", cost: 150000, bonus: 20, rarity: "legendary", category: "조명", set: "boss", requiredLevel: 5 },
        { id: "item_75", name: "사무실 러그", icon: "🟥", cost: 100000, bonus: 14, rarity: "rare", category: "장식", set: "boss", requiredLevel: 5 },
        { id: "item_76", name: "차장실 화분", icon: "🌴", cost: 125000, bonus: 16, rarity: "rare", category: "식물/장식", set: "boss", requiredLevel: 5 },
        { id: "item_77", name: "그림 액자", icon: "🖼️", cost: 150000, bonus: 18, rarity: "legendary", category: "장식", set: "boss", requiredLevel: 5 },
        { id: "item_78", name: "트로피", icon: "🏆", cost: 200000, bonus: 24, rarity: "legendary", category: "장식", set: "boss", requiredLevel: 5 },
        { id: "item_79", name: "금색 명패", icon: "📛", cost: 250000, bonus: 30, rarity: "legendary", category: "장식", set: "boss", requiredLevel: 5 },
        { id: "item_80", name: "고급 커피머신", icon: "☕", cost: 300000, bonus: 36, rarity: "legendary", category: "생활용품", set: "boss", requiredLevel: 5 },

        { id: "item_81", name: "회의실 테이블", icon: "🏢", cost: 400000, bonus: 30, rarity: "legendary", category: "회의실", set: "meeting", requiredLevel: 6 },
        { id: "item_82", name: "회의용 의자 세트", icon: "🪑", cost: 250000, bonus: 20, rarity: "legendary", category: "회의실", set: "meeting", requiredLevel: 6 },
        { id: "item_83", name: "대형 화이트보드", icon: "📋", cost: 200000, bonus: 16, rarity: "legendary", category: "회의실", set: "meeting", requiredLevel: 6 },
        { id: "item_84", name: "회의용 TV", icon: "📺", cost: 500000, bonus: 36, rarity: "legendary", category: "회의실", set: "meeting", requiredLevel: 6 },
        { id: "item_85", name: "화상회의 장비", icon: "🌐", cost: 600000, bonus: 40, rarity: "legendary", category: "회의실", set: "meeting", requiredLevel: 6 },
        { id: "item_86", name: "회의실 스피커", icon: "🔊", cost: 350000, bonus: 24, rarity: "legendary", category: "회의실", set: "meeting", requiredLevel: 6 },
        { id: "item_87", name: "회의실 식물", icon: "🌲", cost: 150000, bonus: 12, rarity: "rare", category: "식물/장식", set: "meeting", requiredLevel: 6 },
        { id: "item_88", name: "회의실 대형 시계", icon: "🕰️", cost: 200000, bonus: 16, rarity: "legendary", category: "장식", set: "meeting", requiredLevel: 6 },
        { id: "item_89", name: "회사 로고 벽면", icon: "🛡️", cost: 750000, bonus: 40, rarity: "legendary", category: "장식", set: "meeting", requiredLevel: 6 },
        { id: "item_90", name: "회의실 간식바", icon: "🍿", cost: 500000, bonus: 30, rarity: "legendary", category: "생활용품", set: "meeting", requiredLevel: 6 },

        { id: "item_91", name: "개인 사무실", icon: "🚪", cost: 1500000, bonus: 40, rarity: "mythic", category: "공간", set: "endgame", requiredLevel: 7 },
        { id: "item_92", name: "통유리 벽", icon: "🪟", cost: 2500000, bonus: 50, rarity: "mythic", category: "공간", set: "endgame", requiredLevel: 7 },

        { id: "item_93", name: "CEO 라운지", icon: "🍸", cost: 4000000, bonus: 60, rarity: "mythic", category: "공간", set: "endgame", requiredLevel: 8 },
        { id: "item_94", name: "개인 카페", icon: "☕", cost: 5000000, bonus: 70, rarity: "mythic", category: "공간", set: "endgame", requiredLevel: 8 },

        { id: "item_95", name: "옥상 정원", icon: "🌻", cost: 7500000, bonus: 80, rarity: "mythic", category: "공간", set: "endgame", requiredLevel: 9 },
        { id: "item_96", name: "전용 회의실", icon: "🏛️", cost: 10000000, bonus: 90, rarity: "mythic", category: "공간", set: "endgame", requiredLevel: 9 },

        { id: "item_97", name: "펜트하우스 사장실", icon: "🏙️", cost: 15000000, bonus: 100, rarity: "mythic", category: "공간", set: "endgame", requiredLevel: 10 },
        { id: "item_98", name: "오피스 사옥 로비", icon: "🏢", cost: 25000000, bonus: 120, rarity: "mythic", category: "공간", set: "endgame", requiredLevel: 10 },
        { id: "item_99", name: "오피스 타워", icon: "🗼", cost: 50000000, bonus: 160, rarity: "mythic", category: "공간", set: "endgame", requiredLevel: 10 },
        { id: "item_100", name: "아키텍처 본사", icon: "🌆", cost: 150000000, bonus: 200, rarity: "mythic", category: "공간", set: "endgame", requiredLevel: 10 },
    ]);

    // 파생 데이터: 원본 bonus에 1.5배 가중치를 적용한 실제 게임용 아이템 목록.
    // 가중치를 바꾸고 싶으면 ITEM_BONUS_MULTIPLIER 하나만 수정하면 됨(매직넘버 제거).
    const ITEM_BONUS_MULTIPLIER = 1.5;
    const shopItems = Object.freeze(
        rawShopItems.map(item => Object.freeze({
            ...item,
            bonus: Math.round(item.bonus * ITEM_BONUS_MULTIPLIER * 10) / 10,
        }))
    );

    const levels = Object.freeze([
        { name: "인턴", cost: 0, desc: "기본 인턴 책상", bonusReward: 0, rebirthReward: 2 },
        { name: "사원", cost: 5000, desc: "사원 사무실 공간", bonusReward: 10, rebirthReward: 5 },
        { name: "주임", cost: 25000, desc: "주임 사무실 공간", bonusReward: 20, rebirthReward: 8 },
        { name: "대리", cost: 75000, desc: "대리 사무실 공간", bonusReward: 30, rebirthReward: 12 },
        { name: "과장", cost: 200000, desc: "과장 사무실 공간", bonusReward: 40, rebirthReward: 16 },
        { name: "차장", cost: 500000, desc: "차장실 공간", bonusReward: 50, rebirthReward: 21 },
        { name: "부장", cost: 1250000, desc: "부장 회의실 공간", bonusReward: 60, rebirthReward: 27 },
        { name: "이사", cost: 3000000, desc: "이사 집무실 공간", bonusReward: 70, rebirthReward: 34 },
        { name: "상무", cost: 7500000, desc: "상무 집무실 공간", bonusReward: 80, rebirthReward: 41 },
        { name: "전무", cost: 20000000, desc: "전무 집무실 공간", bonusReward: 90, rebirthReward: 45 },
        { name: "사장", cost: 50000000, desc: "사장실 펜트하우스", bonusReward: 100, rebirthReward: 50 },
    ]);

    const rarities = Object.freeze({
        normal: { name: "일반", color: "#b0b0b0" },
        advanced: { name: "고급", color: "#4cd137" },
        rare: { name: "희귀", color: "#00a8ff" },
        legendary: { name: "전설", color: "#9c88ff" },
        mythic: { name: "신화", color: "#fbc531" },
    });

    const setEffects = Object.freeze([
        { id: "pc", name: "🖥️ PC 풀세트", items: ["item_16", "item_21", "item_25"], extraBonus: 20 },
        { id: "caffeine", name: "☕ 카페인 생존 세트", items: ["item_32", "item_34", "item_70"], extraBonus: 16 },
        { id: "desk", name: "🪵 기초 책상 세트", items: ["item_1", "item_7", "item_10"], extraBonus: 10 },
        { id: "pro", name: "📑 프로 직장인 세트", items: ["item_46", "item_48", "item_50"], extraBonus: 24 },
        { id: "boss", name: "👑 상사 세트", items: ["item_71", "item_74", "item_79"], extraBonus: 40 },
    ]);

    // id → item 조회를 O(1)로 만들기 위한 인덱스 (아이템 100개+ 로 늘어나도 성능 영향 없음)
    const shopItemsById = new Map(shopItems.map(item => [item.id, item]));

    ns.data = { CONFIG, levels, rarities, shopItems, rawShopItems, setEffects, shopItemsById };
})(window.Workspace);

// js/ui.js
// "state를 읽어서 DOM에 그린다"만 담당. 여기서 state를 직접 변경하지 않는다(단방향 데이터 흐름).
window.Workspace = window.Workspace || {};

(function (ns) {
    const { rarities, shopItems, setEffects, shopItemsById, CONFIG } = ns.data;
    const { makeDraggable } = ns.dragAndDrop;

    class UI {
        constructor(state) {
            this.state = state;
            this.dom = this._cacheDom();
            this._dragCleanups = [];
        }

        _cacheDom() {
            return {
                points: document.getElementById('points'),
                cps: document.getElementById('cps'),
                bonusPct: document.getElementById('bonus-pct'),
                levelName: document.getElementById('level-name'),
                officeRoom: document.getElementById('office-room'),
                officeEmptyMsg: document.getElementById('office-empty-msg'),
                inventoryList: document.getElementById('inventory-list'),
                shopList: document.getElementById('shop-list'),
                shopPromoArea: document.getElementById('shop-promotion-area'),
                setsList: document.getElementById('sets-list'),
                rebirthCount: document.getElementById('rebirth-count'),
                rebirthBonus: document.getElementById('rebirth-bonus'),
                rebirthBtn: document.getElementById('rebirth-action-btn'),
                boostStatus: document.getElementById('boost-status'),
                boostBtn: document.getElementById('boost-action-btn'),
                panels: document.querySelectorAll('.panel'),
                tabBtns: document.querySelectorAll('.tab-btn'),
            };
        }

        renderAll() {
            this.renderTopBar();
            this.renderInventory();
            this.renderShop();
            this.renderSets();
            this.renderStatus();
            this.renderBoostBar();
            this.renderOffice();
        }

        renderTopBar() {
            const { cps, totalBonusPct } = this.state.calculateStats();
            this.dom.points.innerText = Math.floor(this.state.points).toLocaleString();
            this.dom.cps.innerText = cps.toFixed(2);
            this.dom.bonusPct.innerText = totalBonusPct;
            this.dom.levelName.innerText = this.state.getCurrentLevel().name;
        }

        renderInventory() {
            const el = this.dom.inventoryList;
            el.innerHTML = '';

            if (this.state.inventory.size === 0) {
                el.innerHTML = `<div style="font-size:11px; color:#888; text-align:center; padding: 20px;">보유 중인 자산이 없습니다.<br>상점에서 아이템을 구매해보세요!</div>`;
                return;
            }

            const equippedIds = new Set(this.state.equipped.map(e => e.id));
            const frag = document.createDocumentFragment();

            for (const id of this.state.inventory) {
                const item = shopItemsById.get(id);
                if (!item) continue;
                const equipped = equippedIds.has(id);
                const rarity = rarities[item.rarity];

                const div = document.createElement('div');
                div.className = 'item-card';
                div.innerHTML = `
                    <div>
                        <h4>${item.icon} ${item.name} <span style="font-size:9px; color:${rarity.color}">[${rarity.name}]</span></h4>
                        <p>보너스 +${item.bonus}% | 상태: <span style="color:${equipped ? '#00ffcc' : '#aaa'}">${equipped ? '배치 중' : '보유 중'}</span></p>
                    </div>
                    <div class="btn-group">
                        <button class="action-btn equip-btn ${equipped ? 'unequip' : ''}" data-action="toggle-equip" data-id="${item.id}">
                            ${equipped ? '해제' : '배치하기'}
                        </button>
                    </div>
                `;
                frag.appendChild(div);
            }
            el.appendChild(frag);
        }

        renderShop() {
            const listEl = this.dom.shopList;
            const promoEl = this.dom.shopPromoArea;
            listEl.innerHTML = '';
            promoEl.innerHTML = '';

            const currentLevelItems = shopItems
                .filter(item => item.requiredLevel === this.state.levelIdx)
                .slice()
                .sort((a, b) => (this.state.inventory.has(a.id) ? 1 : 0) - (this.state.inventory.has(b.id) ? 1 : 0));

            const frag = document.createDocumentFragment();
            for (const item of currentLevelItems) {
                const owned = this.state.inventory.has(item.id);
                const rarity = rarities[item.rarity];
                const canAfford = this.state.points >= item.cost;

                const div = document.createElement('div');
                div.className = `item-card ${owned ? 'purchased' : ''}`;
                div.innerHTML = `
                    <div>
                        <h4>${item.icon} ${item.name} <span style="font-size:9px; color:${rarity.color}">[${rarity.name}]</span></h4>
                        <p>보너스 +${item.bonus}% | 가격: ${item.cost.toLocaleString()} P</p>
                    </div>
                    <div class="btn-group">
                        <button class="action-btn buy-btn" data-action="buy-item" data-id="${item.id}" ${owned || !canAfford ? 'disabled' : ''}>
                            ${owned ? '보유함' : '구매'}
                        </button>
                    </div>
                `;
                frag.appendChild(div);
            }
            listEl.appendChild(frag);

            const nextLevel = this.state.getNextLevel();
            const promoDiv = document.createElement('div');
            promoDiv.className = 'shop-promo-card';

            if (nextLevel) {
                const canPromo = this.state.points >= nextLevel.cost;
                promoDiv.innerHTML = `
                    <h3>🚀 다음 등급 승진 (${nextLevel.name})</h3>
                    <p>필요 포인트: <b>${nextLevel.cost.toLocaleString()} P</b><br>승진 보너스: +${nextLevel.bonusReward}% 적용<br>${nextLevel.desc}</p>
                    <button class="shop-promo-btn" data-action="buy-promotion" ${!canPromo ? 'disabled' : ''}>
                        ${canPromo ? '승진하기' : '포인트 부족'}
                    </button>
                `;
            } else {
                promoDiv.innerHTML = `
                    <h3>🏆 최고 등급 달성 완료</h3>
                    <p>'직급/환생' 탭에서 언제든 환생이 가능합니다!</p>
                    <button class="shop-promo-btn" data-action="switch-tab" data-tab="status">환생하러 가기</button>
                `;
            }
            promoEl.appendChild(promoDiv);
        }

        renderSets() {
            const el = this.dom.setsList;
            el.innerHTML = '';
            const equippedIds = new Set(this.state.equipped.map(e => e.id));
            const frag = document.createDocumentFragment();

            for (const set of setEffects) {
                const isComplete = set.items.every(id => equippedIds.has(id));
                const div = document.createElement('div');
                div.className = `set-box ${isComplete ? 'active-set' : ''}`;

                const itemsHtml = set.items
                    .map(id => {
                        const item = shopItemsById.get(id);
                        const has = equippedIds.has(id);
                        const label = isComplete ? (item ? `${item.icon} ${item.name}` : '') : (item ? item.icon : '');
                        const titleAttr = isComplete ? '' : ` title="${item ? item.name : ''}"`;
                        return `<span style="color:${has ? '#00ffcc' : '#888'}"${titleAttr}>${label}</span>`;
                    })
                    .join(' | ');

                div.innerHTML = `
                    <div style="font-weight:bold; margin-bottom:4px; color:${isComplete ? '#ffd700' : '#fff'}">
                        ${set.name} ${isComplete ? '(활성화됨!)' : '(미완료)'}
                    </div>
                    <div style="font-size:10px; color:#aaa; margin-bottom:4px;">효과: 추가 보너스 +${set.extraBonus}%</div>
                    <div style="font-size:11px;">필요 아이템: ${itemsHtml}</div>
                `;
                frag.appendChild(div);
            }
            el.appendChild(frag);
        }

        renderStatus() {
            this.dom.rebirthCount.innerText = this.state.rebirthCount;
            this.dom.rebirthBonus.innerText = this.state.totalRebirthBonus;

            const currentLevel = this.state.getCurrentLevel();
            const btn = this.dom.rebirthBtn;

            if (this.state.levelIdx === 0) {
                btn.innerText = `🚫 인턴 기간에는 환생 불가 (사원 승진 필요)`;
                btn.disabled = true;
            } else if (!this.state.canRebirth()) {
                btn.innerText = `🚫 최대 환생 횟수(${CONFIG.MAX_REBIRTH}회) 달성 완료`;
                btn.disabled = true;
            } else {
                btn.innerText = `🚀 [${currentLevel.name}]으로 환생하기 (+${currentLevel.rebirthReward}% 보너스)`;
                btn.disabled = false;
            }
        }

        renderBoostBar() {
            const now = Date.now();
            const active = now < this.state.boostEndTime;

            if (active) {
                const leftSec = Math.ceil((this.state.boostEndTime - now) / 1000);
                this.dom.boostStatus.innerText = `(2배 부스트 작동 중! 남은 시간: ${Math.floor(leftSec / 60)}분 ${leftSec % 60}초)`;
                this.dom.boostStatus.style.color = '#00ffcc';
                this.dom.boostBtn.innerText = '부스트 작동 중';
                this.dom.boostBtn.disabled = true;
            } else {
                this.dom.boostStatus.innerText = '(상시 대기중)';
                this.dom.boostStatus.style.color = '#ffeaa7';
                this.dom.boostBtn.innerText = '사직서 제출 (2배)';
                this.dom.boostBtn.disabled = false;
            }
        }

        renderOffice() {
            this._dragCleanups.forEach(cleanup => cleanup());
            this._dragCleanups = [];

            const room = this.dom.officeRoom;
            room.querySelectorAll('.draggable-item').forEach(el => el.remove());

            if (this.state.equipped.length === 0) {
                this.dom.officeEmptyMsg.style.display = 'block';
                return;
            }
            this.dom.officeEmptyMsg.style.display = 'none';

            for (const eq of this.state.equipped) {
                const item = shopItemsById.get(eq.id);
                if (!item) continue;

                const div = document.createElement('div');
                div.className = 'draggable-item';
                div.innerText = item.icon;
                room.appendChild(div);

                const cleanup = makeDraggable(
                    div,
                    room,
                    { x: eq.x, y: eq.y },
                    () => { /* 실시간 좌표는 pointerup에서 한번만 저장 */ },
                    (x, y) => this.state.updateEquippedPosition(eq.id, x, y)
                );
                this._dragCleanups.push(cleanup);
            }
        }

        switchTab(tabName) {
            this.dom.panels.forEach(p => p.classList.remove('active'));
            this.dom.tabBtns.forEach(b => b.classList.remove('active'));

            const panel = document.getElementById(`${tabName}-panel`);
            if (panel) panel.classList.add('active');

            const btn = document.querySelector(`.tab-btn[data-tab="${tabName}"]`);
            if (btn) btn.classList.add('active');
        }

        openModal(modalId) {
            const modal = document.getElementById(modalId);
            if (modal) modal.style.display = 'flex';
        }

        closeModal(modalId) {
            const modal = document.getElementById(modalId);
            if (modal) modal.style.display = 'none';
        }

        getRandomSpawnPos() {
            const room = this.dom.officeRoom;
            const x = room ? Math.random() * Math.max(0, room.clientWidth - 50) : 50;
            const y = room ? Math.random() * Math.max(0, room.clientHeight - 50) : 50;
            return { x: Math.max(10, x), y: Math.max(10, y) };
        }
    }

    ns.UI = UI;
})(window.Workspace);

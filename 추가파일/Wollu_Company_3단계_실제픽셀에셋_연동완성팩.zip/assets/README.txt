Wollu Company pixel-art item asset pack. 100 PNGs: item_001.png through item_100.png.
